(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,16015,(e,t,s)=>{},98547,(e,t,s)=>{var i=e.i(47167);e.r(16015);var r=e.r(71645),a=r&&"object"==typeof r&&"default"in r?r:{default:r},n=void 0!==i.default&&i.default.env&&!0,o=function(e){return"[object String]"===Object.prototype.toString.call(e)},l=function(){function e(e){var t=void 0===e?{}:e,s=t.name,i=void 0===s?"stylesheet":s,r=t.optimizeForSpeed,a=void 0===r?n:r;d(o(i),"`name` must be a string"),this._name=i,this._deletedRulePlaceholder="#"+i+"-deleted-rule____{}",d("boolean"==typeof a,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=a,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0;var l="u">typeof window&&document.querySelector('meta[property="csp-nonce"]');this._nonce=l?l.getAttribute("content"):null}var t,s=e.prototype;return s.setOptimizeForSpeed=function(e){d("boolean"==typeof e,"`setOptimizeForSpeed` accepts a boolean"),d(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=e,this.inject()},s.isOptimizeForSpeed=function(){return this._optimizeForSpeed},s.inject=function(){var e=this;if(d(!this._injected,"sheet already injected"),this._injected=!0,"u">typeof window&&this._optimizeForSpeed){this._tags[0]=this.makeStyleTag(this._name),this._optimizeForSpeed="insertRule"in this.getSheet(),this._optimizeForSpeed||(n||console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."),this.flush(),this._injected=!0);return}this._serverSheet={cssRules:[],insertRule:function(t,s){return"number"==typeof s?e._serverSheet.cssRules[s]={cssText:t}:e._serverSheet.cssRules.push({cssText:t}),s},deleteRule:function(t){e._serverSheet.cssRules[t]=null}}},s.getSheetForTag=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]},s.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},s.insertRule=function(e,t){if(d(o(e),"`insertRule` accepts only strings"),"u"<typeof window)return"number"!=typeof t&&(t=this._serverSheet.cssRules.length),this._serverSheet.insertRule(e,t),this._rulesCount++;if(this._optimizeForSpeed){var s=this.getSheet();"number"!=typeof t&&(t=s.cssRules.length);try{s.insertRule(e,t)}catch(t){return n||console.warn("StyleSheet: illegal rule: \n\n"+e+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),-1}}else{var i=this._tags[t];this._tags.push(this.makeStyleTag(this._name,e,i))}return this._rulesCount++},s.replaceRule=function(e,t){if(this._optimizeForSpeed||"u"<typeof window){var s="u">typeof window?this.getSheet():this._serverSheet;if(t.trim()||(t=this._deletedRulePlaceholder),!s.cssRules[e])return e;s.deleteRule(e);try{s.insertRule(t,e)}catch(i){n||console.warn("StyleSheet: illegal rule: \n\n"+t+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),s.insertRule(this._deletedRulePlaceholder,e)}}else{var i=this._tags[e];d(i,"old rule at index `"+e+"` not found"),i.textContent=t}return e},s.deleteRule=function(e){if("u"<typeof window)return void this._serverSheet.deleteRule(e);if(this._optimizeForSpeed)this.replaceRule(e,"");else{var t=this._tags[e];d(t,"rule at index `"+e+"` not found"),t.parentNode.removeChild(t),this._tags[e]=null}},s.flush=function(){this._injected=!1,this._rulesCount=0,"u">typeof window?(this._tags.forEach(function(e){return e&&e.parentNode.removeChild(e)}),this._tags=[]):this._serverSheet.cssRules=[]},s.cssRules=function(){var e=this;return"u"<typeof window?this._serverSheet.cssRules:this._tags.reduce(function(t,s){return s?t=t.concat(Array.prototype.map.call(e.getSheetForTag(s).cssRules,function(t){return t.cssText===e._deletedRulePlaceholder?null:t})):t.push(null),t},[])},s.makeStyleTag=function(e,t,s){t&&d(o(t),"makeStyleTag accepts only strings as second parameter");var i=document.createElement("style");this._nonce&&i.setAttribute("nonce",this._nonce),i.type="text/css",i.setAttribute("data-"+e,""),t&&i.appendChild(document.createTextNode(t));var r=document.head||document.getElementsByTagName("head")[0];return s?r.insertBefore(i,s):r.appendChild(i),i},t=[{key:"length",get:function(){return this._rulesCount}}],function(e,t){for(var s=0;s<t.length;s++){var i=t[s];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}(e.prototype,t),e}();function d(e,t){if(!e)throw Error("StyleSheet: "+t+".")}var c=function(e){for(var t=5381,s=e.length;s;)t=33*t^e.charCodeAt(--s);return t>>>0},p={};function h(e,t){if(!t)return"jsx-"+e;var s=String(t),i=e+s;return p[i]||(p[i]="jsx-"+c(e+"-"+s)),p[i]}function u(e,t){"u"<typeof window&&(t=t.replace(/\/style/gi,"\\/style"));var s=e+t;return p[s]||(p[s]=t.replace(/__jsx-style-dynamic-selector/g,e)),p[s]}var m=function(){function e(e){var t=void 0===e?{}:e,s=t.styleSheet,i=void 0===s?null:s,r=t.optimizeForSpeed,a=void 0!==r&&r;this._sheet=i||new l({name:"styled-jsx",optimizeForSpeed:a}),this._sheet.inject(),i&&"boolean"==typeof a&&(this._sheet.setOptimizeForSpeed(a),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var t=e.prototype;return t.add=function(e){var t=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(e.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),"u">typeof window&&!this._fromServer&&(this._fromServer=this.selectFromServer(),this._instancesCounts=Object.keys(this._fromServer).reduce(function(e,t){return e[t]=0,e},{}));var s=this.getIdAndRules(e),i=s.styleId,r=s.rules;if(i in this._instancesCounts){this._instancesCounts[i]+=1;return}var a=r.map(function(e){return t._sheet.insertRule(e)}).filter(function(e){return -1!==e});this._indices[i]=a,this._instancesCounts[i]=1},t.remove=function(e){var t=this,s=this.getIdAndRules(e).styleId;if(function(e,t){if(!e)throw Error("StyleSheetRegistry: "+t+".")}(s in this._instancesCounts,"styleId: `"+s+"` not found"),this._instancesCounts[s]-=1,this._instancesCounts[s]<1){var i=this._fromServer&&this._fromServer[s];i?(i.parentNode.removeChild(i),delete this._fromServer[s]):(this._indices[s].forEach(function(e){return t._sheet.deleteRule(e)}),delete this._indices[s]),delete this._instancesCounts[s]}},t.update=function(e,t){this.add(t),this.remove(e)},t.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},t.cssRules=function(){var e=this,t=this._fromServer?Object.keys(this._fromServer).map(function(t){return[t,e._fromServer[t]]}):[],s=this._sheet.cssRules();return t.concat(Object.keys(this._indices).map(function(t){return[t,e._indices[t].map(function(e){return s[e].cssText}).join(e._optimizeForSpeed?"":"\n")]}).filter(function(e){return!!e[1]}))},t.styles=function(e){var t,s;return t=this.cssRules(),void 0===(s=e)&&(s={}),t.map(function(e){var t=e[0],i=e[1];return a.default.createElement("style",{id:"__"+t,key:"__"+t,nonce:s.nonce?s.nonce:void 0,dangerouslySetInnerHTML:{__html:i}})})},t.getIdAndRules=function(e){var t=e.children,s=e.dynamic,i=e.id;if(s){var r=h(i,s);return{styleId:r,rules:Array.isArray(t)?t.map(function(e){return u(r,e)}):[u(r,t)]}}return{styleId:h(i),rules:Array.isArray(t)?t:[t]}},t.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e,t){return e[t.id.slice(2)]=t,e},{})},e}(),x=r.createContext(null);function b(){return new m}function f(){return r.useContext(x)}x.displayName="StyleSheetContext";var g=a.default.useInsertionEffect||a.default.useLayoutEffect,y="u">typeof window?b():void 0;function v(e){var t=y||f();return t&&("u"<typeof window?t.add(e):g(function(){return t.add(e),function(){t.remove(e)}},[e.id,String(e.dynamic)])),null}v.dynamic=function(e){return e.map(function(e){return h(e[0],e[1])}).join(" ")},s.StyleRegistry=function(e){var t=e.registry,s=e.children,i=r.useContext(x),n=r.useState(function(){return i||t||b()})[0];return a.default.createElement(x.Provider,{value:n},s)},s.createStyleRegistry=b,s.style=v,s.useStyleRegistry=f},37902,(e,t,s)=>{t.exports=e.r(98547).style},10666,e=>{"use strict";var t=e.i(43476),s=e.i(37902),i=e.i(51445),r=e.i(26707),a=e.i(53136),n=e.i(83086),o=e.i(43531),l=e.i(10980),d=e.i(71645),c=e.i(31343),p=e.i(74886),h=e.i(67240);let u=(0,e.i(75254).default)("code-xml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]]);var m=e.i(86536);let x={desktop:1024,tablet:768,mobile:375},b=["Getting Started","Hover Effects","Entrance Animations","Advanced Techniques"],f={beginner:"bg-emerald-500/15 text-emerald-400 border-emerald-500/30",intermediate:"bg-amber-500/15 text-amber-400 border-amber-500/30",advanced:"bg-red-500/15 text-red-400 border-red-500/30"};function g({userCode:e,deviceSize:s,showSolution:i,isDragging:r,onCodeChange:a,onResetCode:n,onRevealSolution:l}){let[b,f]=(0,d.useState)(!1),y=(0,d.useRef)(null),v=(0,d.useRef)(null),w=(0,d.useCallback)(()=>{y.current&&(y.current.srcdoc=e)},[e]),k=(0,d.useMemo)(()=>e,[e]),j=(0,d.useCallback)(async()=>{await navigator.clipboard.writeText(e),f(!0),setTimeout(()=>f(!1),2e3)},[e]),S=(0,d.useCallback)(e=>{if("Tab"===e.key){e.preventDefault();let t=v.current;if(!t)return;let s=t.selectionStart,i=t.selectionEnd,r=t.value;a(r.substring(0,s)+"  "+r.substring(i)),requestAnimationFrame(()=>{t.selectionStart=t.selectionEnd=s+2})}},[a]);return(0,t.jsxs)("div",{className:"flex-1 overflow-hidden flex flex-col",style:{minHeight:"20%"},children:[(0,t.jsxs)("div",{className:"flex items-center gap-1.5 px-4 py-2 border-t border-white/[0.06] shrink-0",children:[(0,t.jsxs)("button",{onClick:w,className:"flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white transition-all",style:{background:"linear-gradient(135deg, #a855f7, #ec4899)"},children:[(0,t.jsx)(c.Play,{className:"w-3 h-3"}),"Run"]}),(0,t.jsxs)("button",{onClick:n,className:"flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all hover:bg-white/[0.04]",style:{borderColor:"rgba(255,255,255,0.1)",color:"#94a3b8"},children:[(0,t.jsx)(h.RotateCcw,{className:"w-3 h-3"}),"Reset"]}),(0,t.jsxs)("button",{onClick:l,className:`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${i?"":"hover:bg-white/[0.04]"}`,style:{borderColor:i?"rgba(168,85,247,0.4)":"rgba(255,255,255,0.1)",background:i?"rgba(168,85,247,0.1)":"transparent",color:i?"#c084fc":"#94a3b8"},children:[(0,t.jsx)(m.Eye,{className:"w-3 h-3"}),i?"Showing Solution":"Show Solution"]}),(0,t.jsx)("div",{className:"flex-1"}),(0,t.jsx)("button",{onClick:j,className:"flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all hover:bg-white/[0.04]",style:{borderColor:"rgba(255,255,255,0.1)",color:"#94a3b8"},children:b?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(o.Check,{className:"w-3 h-3 text-emerald-400"}),(0,t.jsx)("span",{className:"text-emerald-400",children:"Copied!"})]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(p.Copy,{className:"w-3 h-3"}),"Copy"]})})]}),(0,t.jsxs)("div",{className:"flex-1 flex min-h-0",children:[(0,t.jsxs)("div",{className:"flex-1 flex flex-col min-w-0 border-r border-white/[0.06]",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 px-3 py-1.5 shrink-0",style:{background:"rgba(255,255,255,0.02)"},children:[(0,t.jsx)(u,{className:"w-3.5 h-3.5 text-zinc-500"}),(0,t.jsx)("span",{className:"text-[11px] text-zinc-500 font-medium",children:"HTML & CSS"})]}),(0,t.jsx)("textarea",{ref:v,value:e,onChange:e=>{a(e.target.value)},onKeyDown:S,spellCheck:!1,className:"flex-1 w-full resize-none p-4 text-sm leading-relaxed outline-none custom-scrollbar",style:{background:"#1a1a2e",color:"#e2e8f0",fontFamily:"'Fira Code', 'JetBrains Mono', 'SF Mono', 'Cascadia Code', Consolas, monospace",tabSize:2}})]}),(0,t.jsxs)("div",{className:"flex-1 flex flex-col min-w-0",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 px-3 py-1.5 shrink-0",style:{background:"rgba(255,255,255,0.02)"},children:[(0,t.jsx)(m.Eye,{className:"w-3.5 h-3.5 text-zinc-500"}),(0,t.jsx)("span",{className:"text-[11px] text-zinc-500 font-medium",children:"Preview"}),(0,t.jsxs)("span",{className:"text-[10px] text-zinc-600 ml-auto",children:[x[s],"px"]})]}),(0,t.jsx)("div",{className:"flex-1 flex items-center justify-center p-4 overflow-hidden",style:{background:"#111118"},children:(0,t.jsx)("div",{className:"relative rounded-lg overflow-hidden transition-all duration-300",style:{width:`${Math.min(x[s],1024)}px`,height:"100%",maxWidth:"100%",border:"1px solid rgba(255,255,255,0.08)"},children:(0,t.jsx)("iframe",{ref:y,srcDoc:k,title:"Live preview",sandbox:"allow-scripts",className:"w-full h-full bg-white",style:{pointerEvents:r?"none":"auto"}})})})]})]})]})}var y=e.i(41240);function v({lesson:e,showHint:s,onToggleHint:i}){return(0,t.jsx)("div",{className:"overflow-y-auto custom-scrollbar",style:{height:"100%"},children:(0,t.jsxs)("div",{className:"max-w-2xl px-4 sm:px-6 py-5",children:[(0,t.jsx)("div",{className:"flex flex-wrap gap-1.5 mb-4",children:e.concepts.map(e=>(0,t.jsx)("span",{className:"text-[11px] px-2 py-0.5 rounded-full font-medium",style:{background:"rgba(168, 85, 247, 0.1)",color:"#c084fc",border:"1px solid rgba(168, 85, 247, 0.2)"},children:e},e))}),(0,t.jsx)("div",{className:"prose-sm [&_h3]:text-base [&_h3]:font-semibold [&_h3]:text-white [&_h3]:mb-2 [&_p]:text-zinc-300 [&_p]:mb-3 [&_p]:text-sm [&_code]:bg-zinc-800 [&_code]:text-emerald-400 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs [&_ul]:space-y-1 [&_ul]:text-zinc-400 [&_ul]:text-sm [&_li]:pl-1 [&_div]:rounded-lg [&_div]:mb-3 [&_div]:p-3 [&_strong]:text-white",dangerouslySetInnerHTML:{__html:e.explanation}}),(0,t.jsxs)("button",{onClick:i,className:"flex items-center gap-2 mt-4 px-3 py-2 rounded-lg text-sm transition-all",style:{background:s?"rgba(250, 204, 21, 0.1)":"rgba(255,255,255,0.03)",border:s?"1px solid rgba(250, 204, 21, 0.3)":"1px solid rgba(255,255,255,0.06)",color:s?"#facc15":"#94a3b8"},children:[(0,t.jsx)(y.Lightbulb,{className:"w-4 h-4"}),s?"Hide Hint":"Show Hint"]}),s&&(0,t.jsx)("div",{className:"mt-2 px-4 py-3 rounded-lg text-sm",style:{background:"rgba(250, 204, 21, 0.06)",border:"1px solid rgba(250, 204, 21, 0.15)",color:"#fde68a"},children:e.hint})]})})}var w=e.i(63059),k=e.i(37727);let j=[{id:"first-effect",title:"Your First Effect",description:"Apply a fade-in animation to an element",difficulty:"beginner",category:"Getting Started",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Welcome to FerrumEngine!</h3>
      <p class="text-zinc-300 mb-4">Every great journey starts with a single step. In this lesson, you'll apply your first FerrumEngine effect — a smooth fade-in animation.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">FerrumEngine effects are applied via CSS classes. Simply add the class to any HTML element and the animation plays automatically.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Add the <code class="bg-zinc-800 text-emerald-400 px-1.5 py-0.5 rounded text-sm">rc-fade-in</code> class to the div element in the starter code. Watch it come alive!</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>How FerrumEngine CSS classes work</li>
        <li>The fade-in animation effect</li>
        <li>Zero-JS animation philosophy</li>
      </ul>
    `,starterCode:`<div class="container">
  <!-- Add the rc-fade-in class to make this fade in -->
  <div class="box">
    <h1>Hello, Ferrum!</h1>
    <p>Your first animated element</p>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    color: #e2e8f0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .box {
    background: linear-gradient(135deg, #667eea, #764ba2);
    padding: 2.5rem;
    border-radius: 16px;
    text-align: center;
    color: white;
    box-shadow: 0 20px 60px rgba(102, 126, 234, 0.3);
  }
  .box h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
  .box p { opacity: 0.8; font-size: 0.9rem; }
</style>`,solutionCode:`<div class="container">
  <div class="box rc-fade-in">
    <h1>Hello, Ferrum!</h1>
    <p>Your first animated element</p>
  </div>
</div>

<style>
  @keyframes rc-fade-in {
    0% { opacity: 0; transform: translateY(20px); }
    100% { opacity: 1; transform: translateY(0); }
  }
  .rc-fade-in {
    animation: rc-fade-in 0.6s ease-out forwards;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    color: #e2e8f0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .box {
    background: linear-gradient(135deg, #667eea, #764ba2);
    padding: 2.5rem;
    border-radius: 16px;
    text-align: center;
    color: white;
    box-shadow: 0 20px 60px rgba(102, 126, 234, 0.3);
  }
  .box h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
  .box p { opacity: 0.8; font-size: 0.9rem; }
</style>`,hint:"Add 'rc-fade-in' to the class attribute of the div that contains the box. The @keyframes animation will handle the rest!",concepts:["CSS classes","Keyframe animations","Zero-JS approach"]},{id:"hover-transform",title:"Hover Transform",description:"Create a scale-up hover effect on a card",difficulty:"beginner",category:"Hover Effects",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Hover Effects 101</h3>
      <p class="text-zinc-300 mb-4">Hover effects are the bread and butter of interactive UI. They give users immediate feedback and make your interface feel alive.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">CSS <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">transform</code> combined with <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">transition</code> creates smooth hover effects. Use <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">scale()</code> to grow elements.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Write CSS to make the card scale up and add a glow shadow on hover. Use the <code class="bg-zinc-800 text-emerald-400 px-1.5 py-0.5 rounded text-sm">.card:hover</code> selector.</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>CSS transition property</li>
        <li>Transform: scale()</li>
        <li>Box-shadow for glow effects</li>
      </ul>
    `,starterCode:`<div class="card">
  <h2>Hover Me!</h2>
  <p>I react to your cursor</p>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .card {
    background: linear-gradient(135deg, #1e293b, #334155);
    border: 1px solid #475569;
    padding: 2rem;
    border-radius: 12px;
    text-align: center;
    color: #e2e8f0;
    /* Add transition here */
    cursor: pointer;
  }
  /* Add your :hover styles here */
</style>`,solutionCode:`<div class="card">
  <h2>Hover Me!</h2>
  <p>I react to your cursor</p>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .card {
    background: linear-gradient(135deg, #1e293b, #334155);
    border: 1px solid #475569;
    padding: 2rem;
    border-radius: 12px;
    text-align: center;
    color: #e2e8f0;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    cursor: pointer;
  }
  .card:hover {
    transform: scale(1.08);
    box-shadow: 0 0 40px rgba(168, 85, 247, 0.4),
                0 0 80px rgba(168, 85, 247, 0.15);
    border-color: rgba(168, 85, 247, 0.5);
  }
</style>`,hint:"Add 'transition: transform 0.3s ease, box-shadow 0.3s ease;' to .card, then write a .card:hover rule with transform: scale(1.08) and a purple box-shadow.",concepts:["CSS transitions","Transform scale","Box-shadow glow"]},{id:"staggered-entrance",title:"Staggered Entrance",description:"Animate multiple elements in sequence",difficulty:"intermediate",category:"Entrance Animations",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Staggered Animations</h3>
      <p class="text-zinc-300 mb-4">Staggering creates a waterfall effect where elements animate one after another, producing a polished, choreographed feel.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">Use <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">animation-delay</code> with increasing values for each element. Combine with <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">animation-fill-mode: both</code> to keep elements hidden before their delay.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Make three cards fade in one after another with 0.15s delay between each. Use <code class="bg-zinc-800 text-emerald-400 px-1.5 py-0.5 rounded text-sm">nth-child</code> selectors for different delays.</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>Animation-delay for staggering</li>
        <li>Nth-child selectors</li>
        <li>Fill-mode: both for pre-animation state</li>
      </ul>
    `,starterCode:`<div class="container">
  <div class="card">Card 1</div>
  <div class="card">Card 2</div>
  <div class="card">Card 3</div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .container {
    display: flex;
    gap: 16px;
  }
  .card {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    border: 1px solid #334155;
    padding: 2rem 2.5rem;
    border-radius: 12px;
    color: #e2e8f0;
    font-weight: 600;
    /* Add animation properties here */
  }
  /* Add staggered delays with nth-child */
</style>`,solutionCode:`<div class="container">
  <div class="card">Card 1</div>
  <div class="card">Card 2</div>
  <div class="card">Card 3</div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .container {
    display: flex;
    gap: 16px;
  }
  @keyframes stagger-fade {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
  }
  .card {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    border: 1px solid #334155;
    padding: 2rem 2.5rem;
    border-radius: 12px;
    color: #e2e8f0;
    font-weight: 600;
    animation: stagger-fade 0.5s ease both;
  }
  .card:nth-child(1) { animation-delay: 0s; }
  .card:nth-child(2) { animation-delay: 0.15s; }
  .card:nth-child(3) { animation-delay: 0.3s; }
</style>`,hint:"Define a @keyframes animation for fade + translateY. Apply it to .card with fill-mode: both. Use .card:nth-child(2) { animation-delay: 0.15s } and .card:nth-child(3) { animation-delay: 0.3s }.",concepts:["Animation-delay","nth-child","Fill-mode both"]},{id:"glass-morphism",title:"Glass Morphism Card",description:"Build a frosted glass card with backdrop-filter",difficulty:"intermediate",category:"Getting Started",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Glass Morphism</h3>
      <p class="text-zinc-300 mb-4">Glass morphism is a modern design trend that creates frosted glass effects. It uses <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">backdrop-filter: blur()</code> to blur whatever is behind the element.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">The magic trio: <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">background: rgba()</code> for translucency, <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">backdrop-filter: blur()</code> for the frosted effect, and a subtle <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">border</code> to define edges.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Create a glass card that floats over a colorful background. Use backdrop-filter to achieve the frosted look.</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>Backdrop-filter blur</li>
        <li>RGBA backgrounds</li>
        <li>Border for glass edges</li>
      </ul>
    `,starterCode:`<div class="bg-shapes">
  <!-- Colorful background circles -->
  <div class="circle c1"></div>
  <div class="circle c2"></div>
  <div class="circle c3"></div>
  
  <div class="glass-card">
    <h2>Glass Card</h2>
    <p>Make me see-through!</p>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bg-shapes {
    position: relative;
    width: 400px;
    height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .circle {
    position: absolute;
    border-radius: 50%;
  }
  .c1 { width: 200px; height: 200px; background: #a855f7; top: -30px; left: -30px; opacity: 0.6; }
  .c2 { width: 150px; height: 150px; background: #ec4899; bottom: -20px; right: -20px; opacity: 0.6; }
  .c3 { width: 120px; height: 120px; background: #06b6d4; top: 50%; right: 20%; opacity: 0.5; }
  
  .glass-card {
    position: relative;
    padding: 2rem;
    border-radius: 16px;
    color: white;
    text-align: center;
    /* Add glass effect styles here */
  }
</style>`,solutionCode:`<div class="bg-shapes">
  <div class="circle c1"></div>
  <div class="circle c2"></div>
  <div class="circle c3"></div>
  
  <div class="glass-card">
    <h2>Glass Card</h2>
    <p>I can see right through!</p>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #1a1a2e;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bg-shapes {
    position: relative;
    width: 400px;
    height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .circle {
    position: absolute;
    border-radius: 50%;
  }
  .c1 { width: 200px; height: 200px; background: #a855f7; top: -30px; left: -30px; opacity: 0.6; }
  .c2 { width: 150px; height: 150px; background: #ec4899; bottom: -20px; right: -20px; opacity: 0.6; }
  .c3 { width: 120px; height: 120px; background: #06b6d4; top: 50%; right: 20%; opacity: 0.5; }
  
  .glass-card {
    position: relative;
    padding: 2rem;
    border-radius: 16px;
    color: white;
    text-align: center;
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  }
</style>`,hint:"Set background: rgba(255, 255, 255, 0.08), backdrop-filter: blur(20px), and border: 1px solid rgba(255, 255, 255, 0.15) on the .glass-card class.",concepts:["Backdrop-filter blur","RGBA transparency","Glass morphism"]},{id:"text-reveal",title:"Text Reveal Animation",description:"Animated text clip-path reveal effect",difficulty:"intermediate",category:"Entrance Animations",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Text Reveal with Clip-Path</h3>
      <p class="text-zinc-300 mb-4">Clip-path animations create dramatic reveal effects by gradually uncovering content. This technique is widely used in modern landing pages.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">The <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">clip-path: inset()</code> function clips elements to a rectangle. Animating from <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">inset(0 100% 0 0)</code> to <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">inset(0)</code> reveals text from left to right.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Create a text reveal animation using clip-path. The heading should sweep in from left to right.</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>Clip-path inset()</li>
        <li>Animating clip-path</li>
        <li>Dramatic text reveals</li>
      </ul>
    `,starterCode:`<div class="container">
  <h1 class="reveal-text">Hello World</h1>
  <p class="reveal-text delay-1">This text should reveal too</p>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    color: #e2e8f0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .container { text-align: center; }
  h1 {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #a855f7, #ec4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  p {
    font-size: 1.1rem;
    color: #94a3b8;
    margin-top: 0.5rem;
  }
  /* Add reveal animation here */
</style>`,solutionCode:`<div class="container">
  <h1 class="reveal-text">Hello World</h1>
  <p class="reveal-text delay-1">This text reveals too</p>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    color: #e2e8f0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .container { text-align: center; }
  h1 {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #a855f7, #ec4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  p {
    font-size: 1.1rem;
    color: #94a3b8;
    margin-top: 0.5rem;
  }
  @keyframes reveal {
    0% { clip-path: inset(0 100% 0 0); }
    100% { clip-path: inset(0 0 0 0); }
  }
  .reveal-text {
    animation: reveal 0.8s ease-out both;
  }
  .delay-1 {
    animation-delay: 0.3s;
  }
</style>`,hint:"Use @keyframes with clip-path: inset(0 100% 0 0) at 0% and clip-path: inset(0) at 100%. Apply to .reveal-text with animation-fill-mode: both.",concepts:["Clip-path inset","Text gradients","Reveal animations"]},{id:"neon-glow",title:"Neon Glow Button",description:"Create a neon-styled glowing button",difficulty:"intermediate",category:"Hover Effects",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Neon Glow Effects</h3>
      <p class="text-zinc-300 mb-4">Neon effects combine colored text with matching box-shadows to create a glowing, electric feel. This is perfect for CTAs and interactive elements.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">Layer multiple <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">box-shadow</code> values with increasing spread and decreasing opacity for a realistic glow. On hover, intensify the shadows and add <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">text-shadow</code>.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Style the button with a neon glow that intensifies on hover. Choose a vibrant color — cyan, green, or pink!</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>Layered box-shadows</li>
        <li>Text-shadow glow</li>
        <li>Hover state intensification</li>
      </ul>
    `,starterCode:`<div class="container">
  <button class="neon-btn">
    Click Me
  </button>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .neon-btn {
    font-size: 1.2rem;
    font-weight: 700;
    padding: 14px 40px;
    border-radius: 8px;
    cursor: pointer;
    /* Add neon glow styles here */
  }
  /* Add hover state */
</style>`,solutionCode:`<div class="container">
  <button class="neon-btn">
    Click Me
  </button>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .neon-btn {
    font-size: 1.2rem;
    font-weight: 700;
    padding: 14px 40px;
    border-radius: 8px;
    cursor: pointer;
    background: transparent;
    color: #06b6d4;
    border: 2px solid #06b6d4;
    box-shadow: 0 0 10px rgba(6, 182, 212, 0.3),
                0 0 30px rgba(6, 182, 212, 0.1),
                inset 0 0 10px rgba(6, 182, 212, 0.1);
    text-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
    transition: all 0.3s ease;
  }
  .neon-btn:hover {
    background: rgba(6, 182, 212, 0.1);
    box-shadow: 0 0 20px rgba(6, 182, 212, 0.5),
                0 0 60px rgba(6, 182, 212, 0.2),
                0 0 100px rgba(6, 182, 212, 0.1),
                inset 0 0 20px rgba(6, 182, 212, 0.15);
    text-shadow: 0 0 20px rgba(6, 182, 212, 0.8);
  }
</style>`,hint:"Set color and border to cyan (#06b6d4), then layer 3 box-shadows with different spread values and rgba opacity. Intify on hover with larger spreads.",concepts:["Layered box-shadows","Text-shadow","Neon aesthetic"]},{id:"parallax-scroll",title:"Parallax Scroll Effect",description:"Background parallax movement on scroll",difficulty:"advanced",category:"Advanced Techniques",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Parallax Scrolling</h3>
      <p class="text-zinc-300 mb-4">Parallax creates depth by moving background elements at different speeds than foreground content. This creates an immersive 3D-like effect.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">In pure CSS parallax, use <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">perspective</code> on the container and <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">translateZ</code> with different values on child layers. Elements with larger translateZ scroll faster.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Create a parallax container where background shapes move at a different speed than the foreground text.</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>CSS perspective</li>
        <li>TranslateZ for parallax layers</li>
        <li>Overflow handling for parallax containers</li>
      </ul>
    `,starterCode:`<div class="parallax-container">
  <div class="bg-layer">
    <div class="shape s1"></div>
    <div class="shape s2"></div>
    <div class="shape s3"></div>
  </div>
  <div class="content">
    <h1>Parallax Effect</h1>
    <p>Scroll to see the magic</p>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    min-height: 200vh;
    color: #e2e8f0;
  }
  .parallax-container {
    height: 100vh;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bg-layer {
    position: absolute;
    inset: 0;
  }
  .shape {
    position: absolute;
    border-radius: 50%;
  }
  .s1 { width: 300px; height: 300px; background: rgba(168, 85, 247, 0.3); top: 10%; left: 10%; }
  .s2 { width: 200px; height: 200px; background: rgba(236, 72, 153, 0.3); bottom: 10%; right: 15%; }
  .s3 { width: 150px; height: 150px; background: rgba(6, 182, 212, 0.3); top: 40%; left: 60%; }
  .content {
    position: relative;
    text-align: center;
    z-index: 10;
  }
  h1 { font-size: 3rem; font-weight: 800; }
  p { font-size: 1.1rem; color: #94a3b8; margin-top: 0.5rem; }
  /* Add parallax CSS here */
</style>`,solutionCode:`<div class="parallax-container">
  <div class="bg-layer">
    <div class="shape s1"></div>
    <div class="shape s2"></div>
    <div class="shape s3"></div>
  </div>
  <div class="content">
    <h1>Parallax Effect</h1>
    <p>Scroll to see the magic</p>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    min-height: 200vh;
    color: #e2e8f0;
  }
  .parallax-container {
    height: 100vh;
    position: relative;
    overflow-x: hidden;
    overflow-y: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    perspective: 1px;
  }
  .bg-layer {
    position: absolute;
    inset: -50px;
    transform: translateZ(-2px) scale(3);
    z-index: -1;
  }
  .shape {
    position: absolute;
    border-radius: 50%;
    animation: float 6s ease-in-out infinite;
  }
  .s1 { width: 300px; height: 300px; background: rgba(168, 85, 247, 0.3); top: 10%; left: 10%; }
  .s2 { width: 200px; height: 200px; background: rgba(236, 72, 153, 0.3); bottom: 10%; right: 15%; animation-delay: -2s; }
  .s3 { width: 150px; height: 150px; background: rgba(6, 182, 212, 0.3); top: 40%; left: 60%; animation-delay: -4s; }
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-30px); }
  }
  .content {
    position: relative;
    text-align: center;
    z-index: 10;
    transform: translateZ(0);
  }
  h1 { font-size: 3rem; font-weight: 800; }
  p { font-size: 1.1rem; color: #94a3b8; margin-top: 0.5rem; }
</style>`,hint:"Add 'perspective: 1px' to the container. Use 'transform: translateZ(-2px) scale(3)' on the background layer to push it back and scale it up. The content stays at translateZ(0).",concepts:["CSS perspective","TranslateZ","Parallax layers"]},{id:"loading-spinners",title:"Loading Spinner Collection",description:"Compare different loading animation styles",difficulty:"advanced",category:"Advanced Techniques",explanation:`
      <h3 class="text-lg font-semibold text-white mb-3">Loading Spinners</h3>
      <p class="text-zinc-300 mb-4">Loading animations communicate progress and keep users engaged. Different spinner styles suit different brand aesthetics.</p>
      <div class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 mb-4">
        <p class="text-purple-300 text-sm font-medium mb-1">💡 Key Concept</p>
        <p class="text-zinc-300 text-sm">Spinners use <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">@keyframes</code> with <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">rotate()</code> and <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">border-color</code> tricks. Use <code class="bg-zinc-800 text-emerald-400 px-1 rounded text-xs">border-top-color: transparent</code> for the classic arc spinner look.</p>
      </div>
      <p class="text-zinc-300 mb-4">Your task: Create at least 3 different loading spinner styles displayed side by side.</p>
      <h4 class="text-white font-medium mb-2">What you'll learn:</h4>
      <ul class="space-y-1 text-zinc-400 text-sm list-disc list-inside">
        <li>Rotation keyframes</li>
        <li>Border color tricks</li>
        <li>Pulse and bounce animations</li>
      </ul>
    `,starterCode:`<div class="container">
  <div class="spinner-group">
    <div class="spinner-wrapper">
      <div class="spinner spinner-1"></div>
      <span>Arc Spinner</span>
    </div>
    <div class="spinner-wrapper">
      <div class="spinner spinner-2"></div>
      <span>Dual Ring</span>
    </div>
    <div class="spinner-wrapper">
      <div class="spinner spinner-3"></div>
      <span>Pulse Dots</span>
    </div>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .container { text-align: center; }
  .spinner-group {
    display: flex;
    gap: 3rem;
  }
  .spinner-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
  }
  .spinner-wrapper span {
    color: #94a3b8;
    font-size: 0.85rem;
  }
  .spinner {
    /* Base spinner styles */
  }
  /* Add your spinner animations */
</style>`,solutionCode:`<div class="container">
  <div class="spinner-group">
    <div class="spinner-wrapper">
      <div class="spinner spinner-1"></div>
      <span>Arc Spinner</span>
    </div>
    <div class="spinner-wrapper">
      <div class="spinner spinner-2"></div>
      <span>Dual Ring</span>
    </div>
    <div class="spinner-wrapper">
      <div class="spinner spinner-3"></div>
      <span>Pulse Dots</span>
    </div>
  </div>
</div>

<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: system-ui, sans-serif;
    background: #0a0a0a;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  .container { text-align: center; }
  .spinner-group {
    display: flex;
    gap: 3rem;
  }
  .spinner-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
  }
  .spinner-wrapper span {
    color: #94a3b8;
    font-size: 0.85rem;
  }
  
  /* Arc Spinner */
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  .spinner-1 {
    width: 48px;
    height: 48px;
    border: 4px solid rgba(168, 85, 247, 0.2);
    border-top-color: #a855f7;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
  
  /* Dual Ring */
  @keyframes spin-reverse {
    to { transform: rotate(-360deg); }
  }
  .spinner-2 {
    width: 48px;
    height: 48px;
    position: relative;
    animation: spin 1.2s linear infinite;
  }
  .spinner-2::before, .spinner-2::after {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 50%;
    border: 3px solid transparent;
  }
  .spinner-2::before {
    border-top-color: #ec4899;
    border-bottom-color: #ec4899;
  }
  .spinner-2::after {
    border-left-color: #06b6d4;
    border-right-color: #06b6d4;
    animation: spin-reverse 0.8s linear infinite;
    inset: 6px;
  }
  
  /* Pulse Dots */
  .spinner-3 {
    display: flex;
    gap: 6px;
    width: 48px;
    justify-content: center;
  }
  .spinner-3::before, .spinner-3::after {
    content: '';
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #a855f7;
    animation: pulse 1.2s ease-in-out infinite;
  }
  .spinner-3::after { animation-delay: 0.2s; }
  .spinner-3 span { animation: pulse 1.2s ease-in-out 0.4s infinite; }
  @keyframes pulse {
    0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
    40% { transform: scale(1); opacity: 1; }
  }
</style>`,hint:"Spinner 1: border + border-top-color transparent + rotate. Spinner 2: ::before/::after pseudo-elements with different borders and counter-rotation. Spinner 3: Use dots with pulse animation and staggered delays.",concepts:["Rotation animations","Pseudo-elements","Animation staggering"]}];function S({activeLessonId:e,completedLessons:s,sidebarOpen:i,expandedCategories:r,onSelectLesson:a,onToggleCategory:n,onCloseSidebar:l}){let d=function(e){let t={};for(let s of b)t[s]=e.filter(e=>e.category===s);return t}(j);return(0,t.jsx)("aside",{className:`
        lg:w-72 xl:w-80 shrink-0 border-r border-white/[0.06] overflow-hidden
        flex flex-col transition-all duration-300
        ${i?"fixed inset-0 top-[58px] z-30 w-full bg-[#0a0a0a]":"hidden lg:flex"}
      `,children:(0,t.jsxs)("div",{className:"flex-1 overflow-y-auto custom-scrollbar p-4",children:[(0,t.jsx)("button",{onClick:l,className:"lg:hidden absolute top-4 right-4 p-2 rounded-lg hover:bg-white/[0.06] z-10","aria-label":"Close sidebar",children:(0,t.jsx)(k.X,{className:"w-5 h-5 text-zinc-400"})}),(0,t.jsx)("h2",{className:"text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4",children:"Lessons"}),(0,t.jsx)("div",{className:"space-y-1",children:b.map(l=>{let c=d[l]??[],p=r.has(l),h=c.every(e=>s.has(e.id));return(0,t.jsxs)("div",{className:i?"mt-6 lg:mt-0":"",children:[(0,t.jsxs)("button",{onClick:()=>n(l),className:"w-full flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors text-left group",children:[(0,t.jsx)(w.ChevronRight,{className:`w-3.5 h-3.5 text-zinc-500 transition-transform duration-200 ${p?"rotate-90":""}`}),(0,t.jsx)("span",{className:"text-sm font-medium text-zinc-300 flex-1",children:l}),h&&(0,t.jsx)(o.Check,{className:"w-3.5 h-3.5 text-emerald-400"}),(0,t.jsx)("span",{className:"text-xs text-zinc-600",children:c.length})]}),p&&(0,t.jsx)("div",{className:"ml-4 mt-1 space-y-0.5",children:c.map(i=>{let r=i.id===e,n=s.has(i.id);return(0,t.jsxs)("button",{onClick:()=>a(i),className:`
                            w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-all
                            ${r?"border":"hover:bg-white/[0.04]"}
                          `,style:r?{background:"rgba(168, 85, 247, 0.08)",borderColor:"rgba(168, 85, 247, 0.3)"}:{},children:[(0,t.jsx)("div",{className:`
                              w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-all
                              ${n?"border-emerald-500/50 bg-emerald-500/20":"border-zinc-700"}
                            `,children:n?(0,t.jsx)(o.Check,{className:"w-3 h-3 text-emerald-400"}):(0,t.jsx)("div",{className:"w-1.5 h-1.5 rounded-sm bg-zinc-600"})}),(0,t.jsx)("div",{className:"flex-1 min-w-0",children:(0,t.jsx)("div",{className:`text-sm truncate ${r?"text-white font-medium":"text-zinc-400"}`,children:i.title})}),(0,t.jsx)("span",{className:`text-[10px] px-1.5 py-0.5 rounded-full border font-medium shrink-0 ${f[i.difficulty]}`,children:i.difficulty.slice(0,1).toUpperCase()+i.difficulty.slice(1,3)})]},i.id)})})]},l)})})]})})}e.s(["InteractiveDocsView",0,function(){let e=j[0],[c,p]=(0,d.useState)(e.id),[h,u]=(0,d.useState)(e.starterCode),[m,x]=(0,d.useState)(new Set),[y,w]=(0,d.useState)("desktop"),[k,z]=(0,d.useState)(!1),[C,_]=(0,d.useState)(!1),[N,R]=(0,d.useState)(new Set(b)),[A,T]=(0,d.useState)(!1),[F,E]=(0,d.useState)(50),[M,H]=(0,d.useState)(!1),I=(0,d.useRef)(null),P=(0,d.useRef)(0),D=(0,d.useRef)(0),L=(0,d.useMemo)(()=>j.find(e=>e.id===c)??j[0],[c]),Y=Math.round(m.size/j.length*100),B=(0,d.useCallback)(()=>{u(L.starterCode),z(!1),_(!1)},[L]),O=(0,d.useCallback)(()=>{u(L.solutionCode),z(!0)},[L]),$=(0,d.useCallback)(e=>{x(t=>{let s=new Set(t);return s.has(e)?s.delete(e):s.add(e),s})},[]),U=(0,d.useCallback)(e=>{p(e.id),u(m.has(e.id)?e.solutionCode:e.starterCode),z(m.has(e.id)),_(!1),T(!1)},[m]),W=(0,d.useCallback)(e=>{R(t=>{let s=new Set(t);return s.has(e)?s.delete(e):s.add(e),s})},[]),G=(0,d.useCallback)(e=>{e.preventDefault(),H(!0),P.current=e.clientY,D.current=F},[F]);(0,d.useEffect)(()=>{if(!M||!I.current)return;let e=I.current.getBoundingClientRect().height,t=t=>{let s=t.clientY-P.current;E(Math.min(80,Math.max(20,D.current+s/e*100)))},s=()=>H(!1);return window.addEventListener("mousemove",t),window.addEventListener("mouseup",s),()=>{window.removeEventListener("mousemove",t),window.removeEventListener("mouseup",s)}},[M]);let K=(0,d.useCallback)(e=>{u(e),z(!1)},[]);return(0,t.jsxs)("div",{style:{background:"#0a0a0a"},className:"jsx-3e3e29b3161726eb min-h-screen flex flex-col",children:[(0,t.jsx)("header",{style:{background:"rgba(10,10,10,0.85)"},className:"jsx-3e3e29b3161726eb sticky top-0 z-40 border-b border-white/[0.06] backdrop-blur-xl",children:(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb max-w-[1600px] mx-auto px-4 sm:px-6",children:[(0,t.jsx)("div",{style:{background:"rgba(255,255,255,0.06)"},className:"jsx-3e3e29b3161726eb h-0.5 w-full rounded-full overflow-hidden",children:(0,t.jsx)("div",{style:{width:`${Y}%`,background:"linear-gradient(90deg, #a855f7, #ec4899)"},className:"jsx-3e3e29b3161726eb h-full rounded-full transition-all duration-700 ease-out"})}),(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb flex items-center justify-between h-14",children:[(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb flex items-center gap-3",children:[(0,t.jsx)("button",{onClick:()=>T(!A),"aria-label":"Toggle lesson sidebar",className:"jsx-3e3e29b3161726eb lg:hidden p-2 rounded-lg hover:bg-white/[0.06] transition-colors",children:(0,t.jsx)(l.BookOpen,{className:"w-5 h-5 text-zinc-400"})}),(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb flex items-center gap-2.5",children:[(0,t.jsx)("div",{style:{background:"linear-gradient(135deg, #a855f7, #ec4899)"},className:"jsx-3e3e29b3161726eb w-7 h-7 rounded-lg flex items-center justify-center",children:(0,t.jsx)(n.Sparkles,{className:"w-4 h-4 text-white"})}),(0,t.jsx)("span",{className:"jsx-3e3e29b3161726eb text-white font-semibold text-sm hidden sm:block",children:"Interactive Docs"})]}),(0,t.jsxs)("div",{style:{background:"rgba(168,85,247,0.1)",color:"#c084fc"},className:"jsx-3e3e29b3161726eb hidden sm:flex items-center gap-2 ml-4 px-2.5 py-1 rounded-full text-xs",children:[m.size,"/",j.length," completed"]})]}),(0,t.jsxs)("div",{style:{background:"rgba(255,255,255,0.04)"},className:"jsx-3e3e29b3161726eb flex items-center gap-1 p-1 rounded-lg",children:[(0,t.jsx)("button",{onClick:()=>w("desktop"),style:"desktop"===y?{background:"rgba(168,85,247,0.2)"}:{},"aria-label":"Desktop preview",title:"Desktop (1024px)",className:`jsx-3e3e29b3161726eb p-1.5 rounded-md transition-all ${"desktop"===y?"text-white":"text-zinc-500 hover:text-zinc-300"}`,children:(0,t.jsx)(i.Monitor,{className:"w-4 h-4"})}),(0,t.jsx)("button",{onClick:()=>w("tablet"),style:"tablet"===y?{background:"rgba(168,85,247,0.2)"}:{},"aria-label":"Tablet preview",title:"Tablet (768px)",className:`jsx-3e3e29b3161726eb p-1.5 rounded-md transition-all ${"tablet"===y?"text-white":"text-zinc-500 hover:text-zinc-300"}`,children:(0,t.jsx)(a.Tablet,{className:"w-4 h-4"})}),(0,t.jsx)("button",{onClick:()=>w("mobile"),style:"mobile"===y?{background:"rgba(168,85,247,0.2)"}:{},"aria-label":"Mobile preview",title:"Mobile (375px)",className:`jsx-3e3e29b3161726eb p-1.5 rounded-md transition-all ${"mobile"===y?"text-white":"text-zinc-500 hover:text-zinc-300"}`,children:(0,t.jsx)(r.Smartphone,{className:"w-4 h-4"})})]})]})]})}),(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb flex-1 flex max-w-[1600px] mx-auto w-full relative",children:[(0,t.jsx)(S,{activeLessonId:c,completedLessons:m,sidebarOpen:A,expandedCategories:N,onSelectLesson:U,onToggleCategory:W,onCloseSidebar:()=>T(!1)}),(0,t.jsxs)("main",{className:"jsx-3e3e29b3161726eb flex-1 flex flex-col min-w-0",children:[(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb px-4 sm:px-6 py-3 border-b border-white/[0.06] flex items-center justify-between gap-4",children:[(0,t.jsxs)("div",{className:"jsx-3e3e29b3161726eb flex items-center gap-3 min-w-0",children:[(0,t.jsx)("span",{className:`jsx-3e3e29b3161726eb text-[10px] px-1.5 py-0.5 rounded-full border font-medium shrink-0 ${f[L.difficulty]}`,children:L.difficulty.charAt(0).toUpperCase()+L.difficulty.slice(1)}),(0,t.jsx)("h1",{className:"jsx-3e3e29b3161726eb text-white font-semibold text-sm truncate",children:L.title}),(0,t.jsxs)("span",{className:"jsx-3e3e29b3161726eb text-zinc-600 text-xs hidden sm:block",children:["— ",L.description]})]}),(0,t.jsx)("div",{className:"jsx-3e3e29b3161726eb flex items-center gap-1.5 shrink-0",children:(0,t.jsxs)("button",{onClick:()=>$(c),"aria-label":m.has(c)?"Mark incomplete":"Mark complete",className:`jsx-3e3e29b3161726eb p-1.5 rounded-lg border transition-all text-xs font-medium flex items-center gap-1.5 ${m.has(c)?"border-emerald-500/30 bg-emerald-500/10 text-emerald-400":"border-zinc-800 bg-zinc-900 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700"}`,children:[(0,t.jsx)(o.Check,{className:"w-3.5 h-3.5"}),(0,t.jsx)("span",{className:"jsx-3e3e29b3161726eb hidden sm:inline",children:m.has(c)?"Done":"Complete"})]})})]}),(0,t.jsxs)("div",{ref:I,className:"jsx-3e3e29b3161726eb flex-1 flex flex-col relative overflow-hidden",children:[(0,t.jsx)("div",{style:{height:`${F}%`},className:"jsx-3e3e29b3161726eb",children:(0,t.jsx)(v,{lesson:L,showHint:C,onToggleHint:()=>_(!C)})}),(0,t.jsx)("div",{onMouseDown:G,role:"separator","aria-orientation":"horizontal","aria-label":"Resize panels",className:`jsx-3e3e29b3161726eb 
                h-2 shrink-0 cursor-row-resize relative group z-10
                flex items-center justify-center
                ${M?"bg-purple-500/20":"hover:bg-white/[0.04]"}
              `,children:(0,t.jsx)("div",{className:`jsx-3e3e29b3161726eb 
                  w-10 h-0.5 rounded-full transition-colors
                  ${M?"bg-purple-500":"bg-zinc-700 group-hover:bg-zinc-500"}
                `})}),(0,t.jsx)(g,{userCode:h,deviceSize:y,showSolution:k,isDragging:M,onCodeChange:K,onResetCode:B,onRevealSolution:O})]})]})]}),(0,t.jsx)(s.default,{id:"3e3e29b3161726eb",children:".custom-scrollbar::-webkit-scrollbar{width:6px}.custom-scrollbar::-webkit-scrollbar-track{background:0 0}.custom-scrollbar::-webkit-scrollbar-thumb{background:#ffffff14;border-radius:3px}.custom-scrollbar::-webkit-scrollbar-thumb:hover{background:#ffffff26}aside .custom-scrollbar::-webkit-scrollbar{width:4px}"})]})}],10666)},60259,function(e){e.n(e.i(10666))}]);