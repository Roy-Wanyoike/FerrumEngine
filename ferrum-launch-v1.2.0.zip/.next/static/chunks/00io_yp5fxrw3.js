(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,35458,e=>{"use strict";var t=e.i(43476),r=e.i(21218),o=e.i(66992),n=e.i(71645),a=e.i(46696),i=e.i(75157);function s({children:e}){return e}var l=e.i(71467);let d={duration:.6,delay:0,easing:"cubic-bezier(0.33, 1, 0.68, 1)",easingName:"easeOutExpo",iterations:"infinite",direction:"normal",fillMode:"both"},c={tension:120,friction:14,mass:1,bounce:.5},p={primary:"#a855f7",secondary:"#ec4899",bg:"#09090b",surface:"#18181b",text:"#fafafa",radius:12,shadow:.3},u=[{id:"desktop",label:"Desktop",width:1440,height:900,icon:"LayoutDashboard"},{id:"laptop",label:"Laptop",width:1024,height:768,icon:"Square"},{id:"tablet",label:"Tablet",width:768,height:1024,icon:"Tablet"},{id:"mobile",label:"Mobile",width:375,height:812,icon:"Smartphone"}],x=[{name:"Linear",value:"linear"},{name:"Ease",value:"ease"},{name:"Ease In",value:"ease-in"},{name:"Ease Out",value:"ease-out"},{name:"Ease In Out",value:"ease-in-out"},{name:"easeOutExpo",value:"cubic-bezier(0.33, 1, 0.68, 1)",curve:[.33,1,.68,1]},{name:"easeInCubic",value:"cubic-bezier(0.32, 0, 0.67, 0)",curve:[.32,0,.67,0]},{name:"easeOutBack",value:"cubic-bezier(0.34, 1.56, 0.64, 1)",curve:[.34,1.56,.64,1]},{name:"easeOutBounce",value:"cubic-bezier(0.22, 1.2, 0.36, 1)",curve:[.22,1.2,.36,1]},{name:"Spring (Apple)",value:"cubic-bezier(0.175, 0.885, 0.32, 1.275)",curve:[.175,.885,.32,1.275]},{name:"Snappy",value:"cubic-bezier(0.5, 0, 0, 1)",curve:[.5,0,0,1]},{name:"Rubber",value:"cubic-bezier(0, 1.5, 0.5, 1)",curve:[0,1.5,.5,1]}],m=[{id:"card",label:"Card",category:"Layout",icon:"Square",description:"Content container with hover effects"},{id:"button",label:"Button",category:"Interactive",icon:"MousePointerClick",description:"Clickable action element"},{id:"modal",label:"Modal",category:"Overlay",icon:"Maximize",description:"Dialog overlay component"},{id:"dashboard",label:"Dashboard",category:"Layout",icon:"LayoutDashboard",description:"Data grid layout"},{id:"navigation",label:"Navigation",category:"Layout",icon:"Navigation",description:"Top navigation bar"},{id:"hero",label:"Hero Section",category:"Sections",icon:"Star",description:"Full-width hero banner"},{id:"animated-card",label:"3D Card",category:"Motion",icon:"Layers",description:"Card with 3D tilt + spotlight"},{id:"magnetic",label:"Magnetic",category:"Motion",icon:"Zap",description:"Cursor-following pull effect"},{id:"shine-button",label:"Shine Button",category:"Interactive",icon:"Sparkles",description:"Sweep shine on hover"},{id:"ripple-button",label:"Ripple Button",category:"Interactive",icon:"Target",description:"Material ripple on click"},{id:"gradient-text",label:"Gradient Text",category:"Typography",icon:"Type",description:"Animated gradient text"},{id:"floating-element",label:"Floating",category:"Motion",icon:"Wind",description:"Gentle floating animation"},{id:"border-glow-card",label:"Border Glow",category:"Motion",icon:"Crown",description:"Animated gradient border"},{id:"particles",label:"Particles",category:"Effects",icon:"Sparkles",description:"Floating particle field"},{id:"border-beam",label:"Border Beam",category:"Effects",icon:"Gauge",description:"Rotating gradient border"},{id:"gradient-orb",label:"Gradient Orb",category:"Effects",icon:"Eye",description:"Floating gradient sphere"},{id:"text-reveal",label:"Text Reveal",category:"Typography",icon:"Type",description:"Character-by-character reveal"},{id:"number-ticker",label:"Number Ticker",category:"Typography",icon:"BarChart3",description:"Animated counting number"},{id:"shimmer",label:"Shimmer",category:"Effects",icon:"Loader2",description:"Loading shimmer effect"},{id:"pulsing-dot",label:"Pulsing Dot",category:"Effects",icon:"Zap",description:"Animated indicator dot"}],g=[{id:"landing-hero",label:"Landing Hero",description:"Hero with gradient text, floating elements, and particles",components:["hero","gradient-text","floating-element","particles"],effects:[]},{id:"pricing-card",label:"Pricing Card",description:"Animated card with border glow and shine button",components:["card","border-glow-card","shine-button"],effects:[]},{id:"dashboard-widget",label:"Dashboard Widget",description:"Dashboard card with number tickers and shimmer",components:["dashboard","number-ticker","shimmer","pulsing-dot"],effects:[]},{id:"nav-with-effects",label:"Navigation Bar",description:"Navigation with magnetic links and ripple button",components:["navigation","magnetic","ripple-button"],effects:[]},{id:"modal-dialog",label:"Modal Dialog",description:"Modal with backdrop blur and border beam",components:["modal","border-beam"],effects:[]}],h=[{id:"core-animations",name:"Core Animations"},{id:"hover",name:"Hover"},{id:"text",name:"Text"},{id:"backgrounds",name:"Backgrounds"},{id:"loaders",name:"Loaders"},{id:"3d-transforms",name:"3D & Transforms"},{id:"button-card",name:"Buttons & Cards"},{id:"forms",name:"Forms & Inputs"},{id:"navigation",name:"Navigation & UI"},{id:"scroll-micro",name:"Scroll & Micro"},{id:"advanced",name:"Advanced"}],f=[{id:"html",label:"HTML",icon:"code"},{id:"css",label:"CSS",icon:"paintbrush"},{id:"react",label:"React",icon:"atom"},{id:"vue",label:"Vue",icon:"layers"},{id:"svelte",label:"Svelte",icon:"flame"},{id:"angular",label:"Angular",icon:"triangle"},{id:"webcomponents",label:"Web Components",icon:"box"}];var b=e.i(58472),v=e.i(74886),y=e.i(43531);function w({code:e,format:r,onFormatChange:o,onCodeChange:a,onCopy:i,copied:s}){let[l,d]=(0,n.useState)(!1),c=e.split("\n"),p=(0,n.useMemo)(()=>{let t;return t=(t=(t=(t=e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")).replace(/(\/\/[^\n]*)/g,'<span style="color:#6b7280;font-style:italic">$1</span>')).replace(/(\/\*[\s\S]*?\*\/)/g,'<span style="color:#6b7280;font-style:italic">$1</span>')).replace(/(&lt;!--[\s\S]*?--&gt;)/g,'<span style="color:#6b7280;font-style:italic">$1</span>'),("html"===r||"vue"===r||"svelte"===r||"angular"===r||"webcomponents"===r)&&(t=(t=(t=t.replace(/(&lt;\/?)([\w-]+)/g,'$1<span style="color:#f472b6">$2</span>')).replace(/([\w-]+)(=)(&quot;|")/g,'<span style="color:#a78bfa">$1</span>$2$3')).replace(/("(?:[^"\\]|\\.)*")/g,'<span style="color:#fbbf24">$1</span>')),"css"===r&&(t=(t=(t=t.replace(/([\w-]+)(\s*:)/g,'<span style="color:#67e8f9">$1</span>$2')).replace(/:\s*([^;{}\n]+)/g,(e,t)=>': <span style="color:#fbbf24">'+t+"</span>")).replace(/^([.#][\w-]+)/gm,'<span style="color:#f472b6">$1</span>')),("react"===r||"vue"===r||"svelte"===r||"angular"===r||"webcomponents"===r)&&(t=(t=(t=(t=(t=t.replace(/\b(import|from|export|default|const|let|var|function|return|if|else|class|extends|new|this|static|get|set|typeof|interface|type)\b/g,'<span style="color:#c084fc">$1</span>')).replace(/(["'`])(?:(?!\1|\\).|\\.)*\1/g,'<span style="color:#fbbf24">$&</span>')).replace(/\b(\d+\.?\d*)\b/g,'<span style="color:#67e8f9">$1</span>')).replace(/(&lt;\/?)([\w.]+)/g,'$1<span style="color:#f472b6">$2</span>')).replace(/\b(true|false|null|undefined)\b/g,'<span style="color:#f472b6">$1</span>')),t},[e,r]);return(0,t.jsxs)("div",{className:"flex flex-col h-full bg-foreground/[0.005]",children:[(0,t.jsxs)("div",{className:"flex items-center border-b border-border px-2 h-10 shrink-0 gap-0.5",children:[(0,t.jsx)("div",{className:"flex gap-0.5 flex-1 overflow-x-auto",children:f.map(e=>(0,t.jsx)("button",{onClick:()=>o(e.id),className:`text-[11px] px-2.5 py-1.5 rounded-md whitespace-nowrap transition-colors ${r===e.id?"bg-foreground/[0.08] text-foreground font-medium":"text-muted-foreground/50 hover:text-foreground/70 hover:bg-foreground/[0.04]"}`,children:e.label},e.id))}),(0,t.jsxs)("button",{onClick:()=>d(e=>!e),title:l?"Switch to formatted view":"Switch to editable mode",className:`mx-1 flex items-center gap-1 text-[11px] px-2 py-1.5 rounded-md transition-colors shrink-0 ${l?"bg-foreground/[0.08] text-foreground":"text-muted-foreground/50 hover:text-foreground/70 hover:bg-foreground/[0.04]"}`,children:[(0,t.jsx)(b.Code,{size:12}),l?"Edit":"View"]}),(0,t.jsxs)("button",{onClick:i,className:"flex items-center gap-1.5 text-[11px] text-muted-foreground/50 hover:text-foreground/70 transition-colors px-2 py-1.5 rounded-md hover:bg-foreground/[0.04] shrink-0",children:[s?(0,t.jsx)(y.Check,{size:12}):(0,t.jsx)(v.Copy,{size:12}),s?"Copied!":"Copy"]})]}),l?(0,t.jsxs)("div",{className:"flex-1 relative min-h-0",children:[(0,t.jsx)("div",{className:"absolute left-0 top-0 bottom-0 w-12 flex flex-col items-end pr-3 pt-3 text-[11px] text-muted-foreground/25 select-none pointer-events-none overflow-hidden font-mono z-10",children:c.map((e,r)=>(0,t.jsx)("div",{className:"leading-6",children:r+1},r))}),(0,t.jsx)("textarea",{value:e,onChange:e=>a(e.target.value),spellCheck:!1,className:"w-full h-full pl-12 pr-4 pt-3 pb-3 font-mono text-[12px] leading-6 bg-transparent text-foreground/80 resize-none focus:outline-none whitespace-pre-wrap break-all"})]}):(0,t.jsx)("div",{className:"flex-1 overflow-y-auto",children:(0,t.jsxs)("div",{className:"relative p-4 font-mono text-[12px] leading-6",children:[(0,t.jsx)("div",{className:"absolute left-0 top-0 bottom-0 w-12 flex flex-col items-end pr-3 pt-4 text-[11px] text-muted-foreground/25 select-none pointer-events-none",children:c.map((e,r)=>(0,t.jsx)("div",{className:"leading-6",children:r+1},r))}),(0,t.jsx)("pre",{className:"pl-12 whitespace-pre-wrap break-all text-muted-foreground/75",dangerouslySetInnerHTML:{__html:p}})]})})]})}var j=e.i(63059),$=e.i(67240),k=e.i(31245),N=e.i(75254);let C=(0,N.default)("waves",[["path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"knzxuh"}],["path",{d:"M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"2jd2cc"}],["path",{d:"M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"rd2r6e"}]]),z=(0,N.default)("orbit",[["path",{d:"M20.341 6.484A10 10 0 0 1 10.266 21.85",key:"1enhxb"}],["path",{d:"M3.659 17.516A10 10 0 0 1 13.74 2.152",key:"1crzgf"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["circle",{cx:"19",cy:"5",r:"2",key:"mhkx31"}],["circle",{cx:"5",cy:"19",r:"2",key:"v8kfzx"}]]);var S=e.i(47780);let M=(0,N.default)("accessibility",[["circle",{cx:"16",cy:"4",r:"1",key:"1grugj"}],["path",{d:"m18 19 1-7-6 1",key:"r0i19z"}],["path",{d:"m5 8 3-3 5.5 3-2.36 3.5",key:"9ptxx2"}],["path",{d:"M4.24 14.5a5 5 0 0 0 6.88 6",key:"10kmtu"}],["path",{d:"M13.76 17.5a5 5 0 0 0-6.88-6",key:"2qq6rc"}]]);var E=e.i(94827),A=e.i(72664),F=e.i(41929),R=e.i(3116);let B=n.forwardRef(({className:e,children:r,"aria-label":o,...n},a)=>(0,t.jsx)("div",{ref:a,role:"region",tabIndex:0,"aria-label":o,className:(0,i.cn)("overflow-y-auto",e),...n,children:r}));function T({value:e,onValueChange:r,children:o,defaultValue:a,"aria-label":i}){let[s,l]=n.useState(a||""),d=[];return n.Children.forEach(o,e=>{if(n.isValidElement(e)&&e.type===D){let t=e.props,r="string"==typeof t.children?t.children:String(t.children);d.push({value:t.value,label:r})}}),(0,t.jsx)("select",{value:e??s,onChange:e=>{let t=e.target.value;l(t),r?.(t)},"aria-label":i,className:"h-8 text-[11px] bg-foreground/[0.04] border-border rounded-lg px-2 w-full appearance-none cursor-pointer",children:d.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))})}function D({value:e,children:t}){return t}B.displayName="ScrollArea";let L=n.forwardRef(({value:e,onValueChange:r,min:o=0,max:n=100,step:a=1,className:s,disabled:l,orientation:d="horizontal","aria-label":c},p)=>(0,t.jsx)("input",{ref:p,type:"range",min:o,max:n,step:a,value:e[0],onChange:e=>r([Number(e.target.value)]),disabled:l,"aria-label":c,"aria-valuemin":o,"aria-valuemax":n,"aria-valuenow":e[0],className:(0,i.cn)("w-full cursor-pointer accent-purple-500","vertical"===d&&"h-full w-2",l&&"opacity-50 cursor-not-allowed",s)}));function P(e,t){let r=e=>{let t=e.replace("#",""),r=parseInt(t.substring(0,2),16)/255,o=parseInt(t.substring(2,4),16)/255,n=parseInt(t.substring(4,6),16)/255,a=e=>e<=.03928?e/12.92:Math.pow((e+.055)/1.055,2.4);return .2126*a(r)+.7152*a(o)+.0722*a(n)},o=r(e),n=r(t);return((Math.max(o,n)+.05)/(Math.min(o,n)+.05)).toFixed(1)+":1"}function _({motion:e,onMotionChange:o,physics:a,onPhysicsChange:i,theme:s,onThemeChange:l,selectedComponent:d,selectedEffect:c,metrics:u,reducedMotion:m,onToggleReducedMotion:g}){let[h,f]=(0,n.useState)({motion:!0,physics:!1,theme:!1,a11y:!1,metrics:!1,ai:!1}),b=(e,r,o,n)=>{let a=h[e];return(0,t.jsxs)("div",{className:"border-b border-border last:border-b-0",children:[(0,t.jsxs)("button",{onClick:()=>f(t=>({...t,[e]:!t[e]})),"aria-expanded":a,className:"w-full flex items-center gap-2 px-4 py-3 text-left hover:bg-foreground/[0.02] transition-colors",children:[(0,t.jsx)(r,{size:14,className:"text-muted-foreground/65"}),(0,t.jsx)("span",{className:"text-xs font-medium text-foreground/80 flex-1",children:o}),(0,t.jsx)(j.ChevronRight,{size:14,className:`text-muted-foreground/40 transition-transform duration-150 ${a?"rotate-90":""}`})]}),a&&(0,t.jsx)("div",{className:"px-4 pb-4",children:n})]})};return(0,t.jsxs)("div",{className:"w-72 bg-foreground/[0.01] border-l border-border flex flex-col shrink-0 overflow-hidden",children:[(0,t.jsx)("div",{className:"px-4 py-3 border-b border-border",children:(0,t.jsx)("span",{className:"text-xs font-semibold text-foreground/70",children:"Properties"})}),(0,t.jsxs)(B,{className:"flex-1",children:[(0,t.jsx)("div",{className:"px-4 py-2 border-b border-border",children:(0,t.jsxs)("div",{className:"text-[10px] text-muted-foreground/40 space-y-0.5",children:[(0,t.jsxs)("div",{children:["Component: ",(0,t.jsx)("span",{className:"text-foreground/60",children:d})]}),c&&(0,t.jsxs)("div",{children:["Effect: ",(0,t.jsx)("span",{className:"text-foreground/60 font-mono",children:c})]})]})}),b("motion",C,"Motion",(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Duration"}),(0,t.jsxs)("span",{className:"text-foreground/60 font-mono",children:[e.duration.toFixed(1),"s"]})]}),(0,t.jsx)(L,{"aria-label":"Duration",value:[e.duration],onValueChange:e=>o({duration:e[0]}),min:.05,max:5,step:.05,className:"py-1"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Delay"}),(0,t.jsxs)("span",{className:"text-foreground/60 font-mono",children:[e.delay.toFixed(1),"s"]})]}),(0,t.jsx)(L,{"aria-label":"Delay",value:[e.delay],onValueChange:e=>o({delay:e[0]}),min:0,max:3,step:.05,className:"py-1"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1.5",children:"Easing"}),(0,t.jsx)(T,{value:e.easing,onValueChange:e=>{let t=x.find(t=>t.value===e);o({easing:e,easingName:t?.name||e})},"aria-label":"Easing",children:x.map(e=>(0,t.jsx)(D,{value:e.value,children:e.name},e.value))})]}),(0,t.jsx)("div",{className:"h-16 rounded-lg bg-foreground/[0.04] border border-border p-2 relative overflow-hidden",children:(0,t.jsxs)("svg",{width:"100%",height:"100%",viewBox:"0 0 200 48",preserveAspectRatio:"none",children:[(0,t.jsx)("line",{x1:"0",y1:"48",x2:"200",y2:"48",stroke:"rgba(148,163,184,0.15)",strokeWidth:"1"}),(0,t.jsx)("line",{x1:"0",y1:"0",x2:"0",y2:"48",stroke:"rgba(148,163,184,0.15)",strokeWidth:"1"}),(0,t.jsx)("line",{x1:"200",y1:"0",x2:"200",y2:"48",stroke:"rgba(148,163,184,0.15)",strokeWidth:"1"}),(0,t.jsx)("path",{d:(()=>{let t=x.find(t=>t.value===e.easing);if(!t?.curve)return"M0,48 L200,0";let[r,o,n,a]=t.curve;return`M0,48 C${200*r},${48-48*o} ${200*n},${48-48*a} 200,0`})(),fill:"none",stroke:s.primary,strokeWidth:"2",strokeLinecap:"round"})]})}),(0,t.jsxs)("div",{className:"grid grid-cols-2 gap-3",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1.5",children:"Iterations"}),(0,t.jsx)(T,{value:e.iterations,onValueChange:e=>o({iterations:e}),"aria-label":"Iterations",children:["1","2","3","5","10","infinite"].map(e=>(0,t.jsx)(D,{value:e,children:"infinite"===e?"Infinite":`${e}x`},e))})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1.5",children:"Direction"}),(0,t.jsx)(T,{value:e.direction,onValueChange:e=>o({direction:e}),"aria-label":"Direction",children:["normal","reverse","alternate","alternate-reverse"].map(e=>(0,t.jsx)(D,{value:e,children:e},e))})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1.5",children:"Fill Mode"}),(0,t.jsx)(T,{value:e.fillMode,onValueChange:e=>o({fillMode:e}),"aria-label":"Fill Mode",children:["none","forwards","backwards","both"].map(e=>(0,t.jsx)(D,{value:e,children:e},e))})]})]})),b("physics",z,"Physics",(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Tension"}),(0,t.jsx)("span",{className:"text-foreground/60 font-mono",children:a.tension})]}),(0,t.jsx)(L,{"aria-label":"Tension",value:[a.tension],onValueChange:e=>i({tension:e[0]}),min:10,max:300,step:1,className:"py-1"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Friction"}),(0,t.jsx)("span",{className:"text-foreground/60 font-mono",children:a.friction})]}),(0,t.jsx)(L,{"aria-label":"Friction",value:[a.friction],onValueChange:e=>i({friction:e[0]}),min:1,max:50,step:1,className:"py-1"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Mass"}),(0,t.jsx)("span",{className:"text-foreground/60 font-mono",children:a.mass.toFixed(1)})]}),(0,t.jsx)(L,{"aria-label":"Mass",value:[a.mass],onValueChange:e=>i({mass:e[0]}),min:.1,max:5,step:.1,className:"py-1"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Bounce"}),(0,t.jsx)("span",{className:"text-foreground/60 font-mono",children:a.bounce.toFixed(2)})]}),(0,t.jsx)(L,{"aria-label":"Bounce",value:[a.bounce],onValueChange:e=>i({bounce:e[0]}),min:0,max:1,step:.01,className:"py-1"})]}),(0,t.jsxs)("div",{className:"p-2.5 rounded-lg bg-foreground/[0.03] border border-border",children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/40 mb-2",children:"Spring Preview"}),(0,t.jsx)("div",{className:"h-8 relative overflow-hidden rounded bg-foreground/[0.04]",children:(0,t.jsx)("div",{className:"absolute top-1 left-1 w-5 h-5 rounded-full",style:{background:`linear-gradient(135deg, ${s.primary}, ${s.secondary})`,animation:`pg-float ${((300-a.tension+5*a.friction)/50).toFixed(2)}s cubic-bezier(0.34, 1.56, 0.64, 1) infinite alternate`}})})]})]})),b("theme",S.Palette,"Theme",(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1.5",children:"Primary Color"}),(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("input",{type:"color",value:s.primary,onChange:e=>l({primary:e.target.value}),"aria-label":"Primary color picker",className:"w-8 h-8 rounded-md border border-border cursor-pointer bg-transparent"}),(0,t.jsx)("input",{type:"text",value:s.primary,onChange:e=>l({primary:e.target.value}),"aria-label":"Primary color hex value",className:"flex-1 h-8 text-[11px] font-mono bg-foreground/[0.04] border border-border rounded-md px-2 text-foreground"})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1.5",children:"Secondary Color"}),(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("input",{type:"color",value:s.secondary,onChange:e=>l({secondary:e.target.value}),"aria-label":"Secondary color picker",className:"w-8 h-8 rounded-md border border-border cursor-pointer bg-transparent"}),(0,t.jsx)("input",{type:"text",value:s.secondary,onChange:e=>l({secondary:e.target.value}),"aria-label":"Secondary color hex value",className:"flex-1 h-8 text-[11px] font-mono bg-foreground/[0.04] border border-border rounded-md px-2 text-foreground"})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Border Radius"}),(0,t.jsxs)("span",{className:"text-foreground/60 font-mono",children:[s.radius,"px"]})]}),(0,t.jsx)(L,{"aria-label":"Border Radius",value:[s.radius],onValueChange:e=>l({radius:e[0]}),min:0,max:32,step:1,className:"py-1"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between text-[10px] mb-1.5",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:"Shadow Intensity"}),(0,t.jsx)("span",{className:"text-foreground/60 font-mono",children:s.shadow.toFixed(2)})]}),(0,t.jsx)(L,{"aria-label":"Shadow Intensity",value:[100*s.shadow],onValueChange:e=>l({shadow:(e[0]??0)/100}),min:0,max:100,step:1,className:"py-1"})]}),(0,t.jsxs)("button",{onClick:()=>{l(p)},className:"w-full text-[11px] text-muted-foreground/65 hover:text-foreground/70 py-2 border border-border rounded-lg hover:bg-foreground/[0.04] transition-colors flex items-center justify-center gap-1.5",children:[(0,t.jsx)($.RotateCcw,{size:11})," Reset to Default"]})]})),b("a11y",M,"Accessibility",(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between",children:[(0,t.jsx)("span",{className:"text-[11px] text-muted-foreground/60",children:"Reduced Motion"}),(0,t.jsx)("button",{onClick:g,role:"switch","aria-checked":m,"aria-label":"Toggle reduced motion",className:`w-9 h-5 rounded-full transition-colors relative ${m?"bg-foreground/20":"bg-foreground/[0.08]"}`,children:(0,t.jsx)("div",{className:`absolute top-0.5 w-4 h-4 rounded-full bg-foreground transition-transform ${m?"translate-x-4":"translate-x-0.5"}`})})]}),(0,t.jsxs)("div",{className:"space-y-2",children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/65 mb-1",children:"Contrast Ratios"}),[{label:"Primary on BG",ratio:P(s.primary,s.bg),grade:""},{label:"Secondary on BG",ratio:P(s.secondary,s.bg),grade:""}].map(e=>{let r=parseFloat(e.ratio),o=e.grade||(r>=7?"AAA":r>=4.5?"AA":r>=3?"AA Large":"Fail"),n="AAA"===o?"#22c55e":"AA"===o||"AA Large"===o?"#eab308":"#ef4444";return(0,t.jsxs)("div",{className:"flex items-center justify-between text-[11px]",children:[(0,t.jsx)("span",{className:"text-muted-foreground/65",children:e.label}),(0,t.jsxs)("div",{className:"flex items-center gap-1.5",children:[(0,t.jsx)("span",{className:"font-mono text-foreground/60",children:e.ratio}),(0,t.jsx)("span",{className:"text-[9px] px-1.5 py-0.5 rounded font-medium",style:{background:`${n}18`,color:n},children:o})]})]},e.label)})]}),(0,t.jsxs)("div",{className:"p-2.5 rounded-lg bg-foreground/[0.03] border border-border",children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/40 mb-2",children:"Focus Order Preview"}),(0,t.jsx)("div",{className:"space-y-1.5",children:["Primary Button","Secondary Button","Close Action"].map((e,r)=>(0,t.jsxs)("div",{className:"flex items-center gap-2 text-[11px]",children:[(0,t.jsx)("span",{className:"w-4 h-4 rounded text-[9px] flex items-center justify-center bg-foreground/[0.08] text-muted-foreground/65 font-mono",children:r+1}),(0,t.jsx)("span",{className:"text-muted-foreground/60",children:e})]},e))})]})]})),b("metrics",E.Gauge,"Performance",(0,t.jsxs)("div",{className:"space-y-2.5",children:[[{label:"DOM Nodes",value:u.domNodes,icon:A.Box},{label:"CSS Rules",value:u.cssRules,icon:F.FileCode},{label:"Animations",value:u.animations,icon:r.Activity},{label:"Render Time",value:`${u.renderTime}ms`,icon:R.Clock}].map(e=>{let r=e.icon;return(0,t.jsxs)("div",{className:"flex items-center justify-between p-2 rounded-lg bg-foreground/[0.02]",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)(r,{size:13,className:"text-muted-foreground/40"}),(0,t.jsx)("span",{className:"text-[11px] text-muted-foreground/60",children:e.label})]}),(0,t.jsx)("span",{className:"text-[11px] font-mono text-foreground/70",children:e.value})]},e.label)}),(0,t.jsxs)("div",{className:"p-2.5 rounded-lg bg-foreground/[0.03] border border-border",children:[(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/40 mb-2",children:"Bundle Estimate"}),(0,t.jsxs)("div",{className:"flex items-end gap-1",children:[(0,t.jsx)("span",{className:"text-lg font-bold text-foreground/80",children:(.12*u.cssRules+.05*u.domNodes).toFixed(1)}),(0,t.jsx)("span",{className:"text-[10px] text-muted-foreground/40 mb-0.5",children:"KB gzipped"})]})]})]})),b("ai",k.Bot,"AI Assistant",(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsxs)("div",{className:"p-4 rounded-xl bg-gradient-to-b from-foreground/[0.04] to-foreground/[0.01] border border-border text-center",children:[(0,t.jsx)("div",{className:"w-10 h-10 mx-auto mb-3 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/10 flex items-center justify-center",children:(0,t.jsx)(k.Bot,{size:20,className:"text-purple-400/60"})}),(0,t.jsx)("div",{className:"text-xs font-medium text-foreground/70 mb-1",children:"Ferrum AI"}),(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/40 leading-relaxed",children:"Describe what you want to build, and AI will generate the component, effects, and motion configuration for you."})]}),(0,t.jsx)("div",{className:"relative",children:(0,t.jsx)("input",{type:"text",placeholder:"Describe a component...",disabled:!0,"aria-label":"AI component description (coming in v2.1)",className:"w-full h-9 text-[11px] bg-foreground/[0.04] border border-border rounded-lg pl-3 pr-3 text-foreground placeholder:text-muted-foreground/30 disabled:opacity-40 cursor-not-allowed"})}),(0,t.jsx)("div",{className:"text-[10px] text-center text-muted-foreground/30",children:"Coming in v2.1"})]}))]})]})}L.displayName="Slider";var I=e.i(55436),K=e.i(83086);let V=(0,N.default)("component",[["path",{d:"M15.536 11.293a1 1 0 0 0 0 1.414l2.376 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",key:"1uwlt4"}],["path",{d:"M2.297 11.293a1 1 0 0 0 0 1.414l2.377 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414L6.088 8.916a1 1 0 0 0-1.414 0z",key:"10291m"}],["path",{d:"M8.916 17.912a1 1 0 0 0 0 1.415l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.415l-2.377-2.376a1 1 0 0 0-1.414 0z",key:"1tqoq1"}],["path",{d:"M8.916 4.674a1 1 0 0 0 0 1.414l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",key:"1x6lto"}]]),Y=(0,N.default)("layout-template",[["rect",{width:"18",height:"7",x:"3",y:"3",rx:"1",key:"f1a2em"}],["rect",{width:"9",height:"7",x:"3",y:"14",rx:"1",key:"jqznyg"}],["rect",{width:"5",height:"7",x:"16",y:"14",rx:"1",key:"q5h2i8"}]]);var q=e.i(50596);function O({active:e,onChange:r}){let o=[{id:"components",icon:V,label:"Components"},{id:"effects",icon:K.Sparkles,label:"Effects"},{id:"templates",icon:Y,label:"Templates"}];return(0,t.jsx)("div",{className:"w-12 bg-foreground/[0.02] border-r border-border flex flex-col items-center pt-3 gap-1 shrink-0",children:o.map(o=>{let n=o.icon,a=e===o.id;return(0,t.jsxs)("button",{onClick:()=>r(o.id),title:o.label,className:`w-9 h-9 rounded-lg flex items-center justify-center transition-all duration-150 mb-0.5 relative ${a?"bg-foreground/[0.08] text-foreground":"text-muted-foreground/60 hover:text-foreground/80 hover:bg-foreground/[0.04]"}`,children:[(0,t.jsx)(n,{size:18}),a&&(0,t.jsx)("div",{className:"absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-foreground rounded-r-full"})]},o.id)})})}function H({activity:e,selectedComponent:r,onSelectComponent:o,selectedEffect:a,onSelectEffect:i,onSelectTemplate:s,effectsList:l,search:d,setSearch:c,effectCategory:p,setEffectCategory:u}){let x=(0,n.useMemo)(()=>{let e={};return m.forEach(t=>{e[t.category]||(e[t.category]=[]),e[t.category].push(t)}),e},[]),f=(0,n.useMemo)(()=>{let e=l;if("all"!==p&&(e=e.filter(e=>e.category===p)),d){let t=d.toLowerCase();e=e.filter(e=>e.name.toLowerCase().includes(t)||e.className.includes(t))}return e.slice(0,80)},[l,p,d]);return(0,t.jsxs)("div",{className:"w-64 bg-foreground/[0.01] border-r border-border flex flex-col shrink-0",children:[(0,t.jsx)("div",{className:"p-3 border-b border-border",children:(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)(I.Search,{size:14,className:"absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground/40"}),(0,t.jsx)("input",{type:"text",value:d,onChange:e=>c(e.target.value),placeholder:"effects"===e?"Search effects...":"Search components...","aria-label":"effects"===e?"Search effects":"Search components",className:"w-full h-8 pl-8 pr-3 text-xs bg-foreground/[0.04] border border-border rounded-lg focus:outline-none focus:border-foreground/20 text-foreground placeholder:text-muted-foreground/40 transition-colors"})]})}),(0,t.jsxs)("div",{className:"flex-1 overflow-y-auto",children:["components"===e&&(0,t.jsx)("div",{className:"p-2",children:Object.entries(x).map(([e,n])=>(0,t.jsxs)("div",{className:"mb-3",children:[(0,t.jsx)("div",{className:"text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/50 px-2 mb-1.5",children:e}),n.map(e=>{let n=(0,q.resolveIcon)(e.icon),a=r===e.id;return(0,t.jsxs)("button",{onClick:()=>o(e.id),className:`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-all duration-100 mb-0.5 group ${a?"bg-foreground/[0.08] text-foreground":"text-muted-foreground/70 hover:bg-foreground/[0.04] hover:text-foreground/90"}`,children:[(0,t.jsx)(n,{size:15,className:a?"text-foreground":"text-muted-foreground/40 group-hover:text-foreground/60"}),(0,t.jsxs)("div",{className:"min-w-0",children:[(0,t.jsx)("div",{className:"text-xs font-medium truncate",children:e.label}),(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/40 truncate",children:e.description})]})]},e.id)})]},e))}),"effects"===e&&(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex flex-wrap gap-1 px-3 pt-2 pb-1",children:[(0,t.jsx)("button",{onClick:()=>u("all"),className:`text-[10px] px-2 py-1 rounded-md transition-colors ${"all"===p?"bg-foreground/[0.1] text-foreground":"text-muted-foreground/50 hover:bg-foreground/[0.04]"}`,children:"All"}),h.map(e=>(0,t.jsx)("button",{onClick:()=>u(e.id),className:`text-[10px] px-2 py-1 rounded-md transition-colors ${p===e.id?"bg-foreground/[0.1] text-foreground":"text-muted-foreground/50 hover:bg-foreground/[0.04]"}`,children:e.name},e.id))]}),(0,t.jsxs)("div",{className:"p-2",children:[f.map(e=>{let r=a===e.className;return(0,t.jsxs)("button",{onClick:()=>i(e.className),className:`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-all duration-100 mb-0.5 ${r?"bg-foreground/[0.08] text-foreground":"text-muted-foreground/70 hover:bg-foreground/[0.04] hover:text-foreground/90"}`,children:[(0,t.jsx)("div",{className:`w-7 h-7 rounded-md bg-foreground/[0.06] border border-border flex items-center justify-center shrink-0 ${r?"border-foreground/20":""}`,children:(0,t.jsx)("div",{className:"w-3 h-3 rounded-sm bg-gradient-to-br from-purple-500/40 to-pink-500/40"})}),(0,t.jsxs)("div",{className:"min-w-0",children:[(0,t.jsx)("div",{className:"text-xs font-medium truncate",children:e.name}),(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/40 truncate font-mono",children:e.className})]})]},e.className)}),0===f.length&&(0,t.jsx)("div",{className:"text-xs text-muted-foreground/40 text-center py-8",children:"No effects found"})]})]}),"templates"===e&&(0,t.jsx)("div",{className:"p-2",children:g.map(e=>(0,t.jsxs)("button",{onClick:()=>s(e),className:"w-full text-left p-3 rounded-lg border border-border bg-foreground/[0.01] hover:bg-foreground/[0.04] transition-colors mb-2 group",children:[(0,t.jsx)("div",{className:"text-xs font-semibold text-foreground/90 mb-1 group-hover:text-foreground",children:e.label}),(0,t.jsx)("div",{className:"text-[10px] text-muted-foreground/50 leading-relaxed mb-2",children:e.description}),(0,t.jsx)("div",{className:"flex flex-wrap gap-1",children:e.components.map(e=>(0,t.jsx)("span",{className:"text-[9px] px-1.5 py-0.5 rounded bg-foreground/[0.06] text-muted-foreground/50",children:e},e))})]},e.id))})]})]})}function U({html:e,device:r,customWidth:o,onDeviceChange:a}){let i=u.find(e=>e.id===r)??u[0],s="custom"===r?o:i.width,l="custom"===r?600:Math.min(i.height,800),d=(0,n.useRef)(null);return(0,n.useEffect)(()=>{d.current&&(d.current.srcdoc=e)},[e]),(0,t.jsxs)("div",{className:"flex-1 flex flex-col bg-foreground/[0.005] min-h-0",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between border-b border-border px-3 h-10 shrink-0",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsxs)("div",{className:"flex gap-1.5",children:[(0,t.jsx)("div",{className:"w-3 h-3 rounded-full bg-red-500/60"}),(0,t.jsx)("div",{className:"w-3 h-3 rounded-full bg-yellow-500/60"}),(0,t.jsx)("div",{className:"w-3 h-3 rounded-full bg-green-500/60"})]}),(0,t.jsx)("span",{className:"text-[11px] text-muted-foreground/40 ml-2",children:"Preview"})]}),(0,t.jsx)("div",{className:"flex items-center gap-1",children:u.map(e=>{let o=(0,q.resolveIcon)(e.icon);return(0,t.jsx)("button",{onClick:()=>a(e.id),title:`${e.label} (${e.width}px)`,className:`w-7 h-7 rounded-md flex items-center justify-center transition-colors ${r===e.id?"bg-foreground/[0.08] text-foreground":"text-muted-foreground/40 hover:text-foreground/60 hover:bg-foreground/[0.04]"}`,children:(0,t.jsx)(o,{size:14})},e.id)})})]}),(0,t.jsx)("div",{className:"flex-1 flex items-center justify-center p-4 overflow-auto border border-border/20 bg-background",children:(0,t.jsx)("div",{className:"bg-foreground/[0.01] border border-border rounded-xl overflow-hidden transition-all duration-300 shadow-2xl",style:{width:"desktop"===r?"100%":`${Math.min(s,800)}px`,maxWidth:"100%",height:"desktop"===r?"100%":`${l}px`},children:(0,t.jsx)("iframe",{ref:d,title:"Ferrum Playground Preview",className:"w-full h-full border-0",sandbox:"allow-scripts"})})})]})}var G=e.i(71689),W=e.i(31343),X=e.i(86536);let Z=(0,N.default)("square-split-horizontal",[["path",{d:"M8 19H5c-1 0-2-1-2-2V7c0-1 1-2 2-2h3",key:"lubmu8"}],["path",{d:"M16 5h3c1 0 2 1 2 2v10c0 1-1 2-2 2h-3",key:"1ag34g"}],["line",{x1:"12",x2:"12",y1:"4",y2:"20",key:"1tx1rr"}]]),J=(0,N.default)("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]),Q=(0,N.default)("keyboard",[["path",{d:"M10 8h.01",key:"1r9ogq"}],["path",{d:"M12 12h.01",key:"1mp3jc"}],["path",{d:"M14 8h.01",key:"1primd"}],["path",{d:"M16 12h.01",key:"1l6xoz"}],["path",{d:"M18 8h.01",key:"emo2bl"}],["path",{d:"M6 8h.01",key:"x9i8wu"}],["path",{d:"M7 16h10",key:"wp8him"}],["path",{d:"M8 12h.01",key:"czm47f"}],["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}]]);var ee=e.i(64659);function et({onBack:e,viewMode:r,onViewModeChange:o,onExport:a,copied:i,onCopy:s}){let[l,d]=(0,n.useState)(!1),[c,p]=(0,n.useState)(-1),[u,x]=(0,n.useState)(!1),m=(0,n.useRef)(null),g=(0,n.useRef)(null);return(0,n.useEffect)(()=>{if(!u)return;let e=document.activeElement,t=m.current;if(t){let e=t.querySelectorAll('button, a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])');e.length>0?e[0].focus():t.focus()}let r=e=>{if("Escape"===e.key){e.preventDefault(),x(!1);return}if("Tab"!==e.key||!t)return;let r=t.querySelectorAll('button, a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])');if(0===r.length)return;let o=r[0],n=r[r.length-1];e.shiftKey&&document.activeElement===o?(e.preventDefault(),n.focus()):e.shiftKey||document.activeElement!==n||(e.preventDefault(),o.focus())};return document.addEventListener("keydown",r),()=>{document.removeEventListener("keydown",r),e?.focus()}},[u]),(0,n.useEffect)(()=>{if(!l)return;let e=e=>{"Escape"===e.key&&d(!1)};return document.addEventListener("keydown",e),()=>document.removeEventListener("keydown",e)},[l]),(0,n.useEffect)(()=>{if(!l)return;let e=e=>{g.current&&!g.current.contains(e.target)&&d(!1)};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[l]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"h-12 bg-foreground/[0.02] border-b border-border flex items-center px-3 gap-2 shrink-0",children:[(0,t.jsx)("button",{onClick:e,title:"Back to Home",className:"w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/60 hover:text-foreground hover:bg-foreground/[0.06] transition-colors",children:(0,t.jsx)(G.ArrowLeft,{size:16})}),(0,t.jsxs)("div",{className:"flex items-center gap-2.5 ml-1",children:[(0,t.jsx)("div",{className:"w-5 h-5 rounded bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center",children:(0,t.jsx)(W.Play,{size:10,className:"text-white"})}),(0,t.jsx)("span",{className:"text-sm font-semibold text-foreground/90",children:"Playground"}),(0,t.jsx)("span",{className:"text-[10px] px-1.5 py-0.5 rounded bg-purple-500/15 text-purple-400 font-medium",children:"v2.0"})]}),(0,t.jsx)("div",{className:"flex-1"}),(0,t.jsx)("div",{className:"flex items-center bg-foreground/[0.04] rounded-lg p-0.5",children:[{id:"split",icon:Z,label:"Split"},{id:"code",icon:b.Code,label:"Code"},{id:"preview",icon:X.Eye,label:"Preview"}].map(e=>{let n=e.icon,a=r===e.id;return(0,t.jsxs)("button",{onClick:()=>o(e.id),title:`${e.label} View`,className:`h-7 px-2.5 rounded-md flex items-center gap-1.5 text-[11px] transition-colors ${a?"bg-foreground/[0.08] text-foreground font-medium shadow-sm":"text-muted-foreground/50 hover:text-foreground/70"}`,children:[(0,t.jsx)(n,{size:13}),(0,t.jsx)("span",{className:"hidden sm:inline",children:e.label})]},e.id)})}),(0,t.jsx)("div",{className:"w-px h-5 bg-border mx-1"}),(0,t.jsx)("button",{onClick:s,title:"Copy Code",className:"w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/60 hover:text-foreground hover:bg-foreground/[0.06] transition-colors",children:i?(0,t.jsx)(y.Check,{size:15}):(0,t.jsx)(v.Copy,{size:15})}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsxs)("button",{onClick:()=>{p(-1),d(!l)},"aria-expanded":l,"aria-haspopup":"menu",className:"h-8 px-3 rounded-lg flex items-center gap-1.5 text-[11px] bg-foreground/[0.06] text-foreground/80 hover:bg-foreground/[0.1] transition-colors font-medium",children:[(0,t.jsx)(J,{size:13}),"Export",(0,t.jsx)(ee.ChevronDown,{size:11})]}),l&&(0,t.jsx)("div",{ref:g,role:"menu",className:"absolute right-0 top-full mt-1.5 w-52 bg-background border border-border rounded-xl shadow-xl py-1.5 z-50",onKeyDown:e=>{"ArrowDown"===e.key?(e.preventDefault(),p(e=>(e+1)%f.length)):"ArrowUp"===e.key?(e.preventDefault(),p(e=>(e-1+f.length)%f.length)):"Enter"===e.key&&c>=0&&(e.preventDefault(),a(),d(!1),p(-1))},children:f.map((e,r)=>(0,t.jsxs)("button",{role:"menuitem",ref:e=>{e&&r===c&&e.focus()},onClick:()=>{a(),d(!1),p(-1)},className:"w-full flex items-center gap-2.5 px-3 py-2 text-[11px] text-foreground/70 hover:bg-foreground/[0.04] hover:text-foreground transition-colors text-left",children:[(0,t.jsx)(F.FileCode,{size:14,className:"text-muted-foreground/40"}),e.label]},e.id))})]}),(0,t.jsx)("button",{onClick:()=>x(!u),title:"Keyboard Shortcuts",className:"w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/50 hover:text-foreground/70 hover:bg-foreground/[0.06] transition-colors",children:(0,t.jsx)(Q,{size:14})})]}),u&&(0,t.jsx)("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm",onClick:()=>x(!1),role:"presentation",children:(0,t.jsxs)("div",{ref:m,role:"dialog","aria-modal":"true","aria-label":"Keyboard Shortcuts",tabIndex:-1,className:"bg-background border border-border rounded-2xl shadow-2xl p-6 w-80 outline-none",onClick:e=>e.stopPropagation(),children:[(0,t.jsx)("div",{className:"text-sm font-semibold text-foreground mb-4",id:"shortcuts-title",children:"Keyboard Shortcuts"}),(0,t.jsx)("div",{className:"space-y-2",children:[{keys:"⌘ 1 / 2 / 3",desc:"Switch view mode"},{keys:"⌘ B",desc:"Toggle sidebar"},{keys:"⌘ E",desc:"Toggle controls"},{keys:"⌘ C",desc:"Copy code"},{keys:"⌘ S",desc:"Export current format"},{keys:"Esc",desc:"Back to home"}].map(e=>(0,t.jsxs)("div",{className:"flex items-center justify-between py-1.5",children:[(0,t.jsx)("span",{className:"text-xs text-muted-foreground/60",children:e.desc}),(0,t.jsx)("kbd",{className:"text-[10px] font-mono bg-foreground/[0.06] text-foreground/60 px-2 py-0.5 rounded border border-border",children:e.keys})]},e.desc))})]})})]})}function er({direction:e,onResize:r}){let o=(0,n.useRef)(!1),a=(0,n.useRef)(0),i=(0,n.useCallback)(t=>{t.preventDefault(),o.current=!0,a.current="horizontal"===e?t.clientX:t.clientY;let n=t=>{if(!o.current)return;let n="horizontal"===e?t.clientX:t.clientY;r(n-a.current),a.current=n},i=()=>{o.current=!1,document.removeEventListener("mousemove",n),document.removeEventListener("mouseup",i),document.body.style.cursor="",document.body.style.userSelect=""};document.addEventListener("mousemove",n),document.addEventListener("mouseup",i),document.body.style.cursor="horizontal"===e?"col-resize":"row-resize",document.body.style.userSelect="none"},[e,r]);return(0,t.jsx)("div",{onMouseDown:i,className:`shrink-0 flex items-center justify-center group z-10 ${"horizontal"===e?"w-1.5 cursor-col-resize hover:bg-foreground/[0.06] active:bg-foreground/[0.1] transition-colors":"h-1.5 cursor-row-resize hover:bg-foreground/[0.06] active:bg-foreground/[0.1] transition-colors"}`,children:(0,t.jsx)("div",{className:`${"horizontal"===e?"w-0.5 h-6 rounded-full bg-foreground/[0.08] group-hover:bg-foreground/[0.15] group-active:bg-foreground/25 transition-colors":"h-0.5 w-6 rounded-full bg-foreground/[0.08] group-hover:bg-foreground/[0.15] group-active:bg-foreground/25 transition-colors"}`})})}e.s(["PlaygroundV2",0,function({onBack:i}){let[u,x]=(0,n.useState)("components"),[m,g]=(0,n.useState)("split"),[h,f]=(0,n.useState)("react"),[b,v]=(0,n.useState)(!1),y=(0,n.useRef)(null),[j,$]=(0,n.useState)(null),[k,N]=(0,n.useState)(""),[C,z]=(0,n.useState)("all"),[S,M]=(0,n.useState)(!1),[E,A]=(0,n.useState)("card"),[F,R]=(0,n.useState)(""),[B,T]=(0,n.useState)("desktop"),[D,L]=(0,n.useState)(800),[P,I]=(0,n.useState)(d),[K,V]=(0,n.useState)(c),[Y,q]=(0,n.useState)(p),[G,W]=(0,n.useState)(!0),[X,Z]=(0,n.useState)(!0),[J,Q]=(0,n.useState)(55),[ee,eo]=(0,n.useState)(272),[en,ea]=(0,n.useState)(288),[ei,es]=(0,n.useState)([]);(0,n.useEffect)(()=>{e.A(2445).then(e=>{es(e.effects||[])})},[]);let[el,ed]=(0,n.useState)("");(0,n.useEffect)(()=>{if(!F)return void ed("");let e=ei.find(e=>e.className===F),t=e?.category||"";(0,l.getEffectCSS)(t,F).then(e=>{ed(e||"")}).catch(()=>ed(""))},[F,ei]),(0,n.useEffect)(()=>{C&&"all"!==C&&(0,l.preloadCategory)(C)},[C]);let ec=(0,n.useMemo)(()=>{var e,t,r;let o,n,a,i,s,l,d,c,p,u,x,m,g;return e=S?{...P,duration:0,iterations:"1"}:P,o=Y.primary,n=Y.secondary,a=Y.surface,i=Y.text,s=Y.radius,l=e.duration,d=e.delay,c=e.easing,p=e.iterations,u=e.direction,x=e.fillMode,m=`background:${a};color:${i};border-radius:${s}px;font-family:system-ui,-apple-system,sans-serif;`,t=(g={card:`
      <div style="${m} padding:24px; max-width:320px; box-shadow:0 4px 24px rgba(0,0,0,${Y.shadow}); border:1px solid rgba(255,255,255,0.08); transition: transform ${l}s ${c}, box-shadow ${l}s ${c}; cursor:pointer;" onmouseenter="this.style.transform='translateY(-4px) scale(1.02)';this.style.boxShadow='0 8px 32px ${o}33'" onmouseleave="this.style.transform='';this.style.boxShadow='0 4px 24px rgba(0,0,0,${Y.shadow})'">
        <div style="width:40px;height:40px;border-radius:8px;background:linear-gradient(135deg,${o},${n});margin-bottom:16px;"></div>
        <h3 style="font-size:18px;font-weight:600;margin:0 0 8px;color:${i}">Component Card</h3>
        <p style="font-size:14px;color:${i}99;margin:0;line-height:1.6;">A versatile card component with hover lift effect and gradient accent.</p>
        <div style="display:flex;gap:8px;margin-top:16px;">
          <span style="font-size:12px;padding:4px 10px;border-radius:20px;background:${o}22;color:${o};">Design</span>
          <span style="font-size:12px;padding:4px 10px;border-radius:20px;background:${n}22;color:${n};">Motion</span>
        </div>
      </div>`,button:`
      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
        <button style="padding:12px 28px;border:none;border-radius:${s}px;background:linear-gradient(135deg,${o},${n});color:white;font-size:15px;font-weight:600;cursor:pointer;transition:transform ${l}s ${c},box-shadow ${l}s ${c};animation:pg-pulse ${3*l}s ${c} ${p} ${u};animation-fill-mode:${x};" onmouseenter="this.style.transform='scale(1.05)';this.style.boxShadow='0 4px 20px ${o}55'" onmouseleave="this.style.transform='';this.style.boxShadow=''">Get Started</button>
        <button style="padding:12px 28px;border:1px solid ${o}44;border-radius:${s}px;background:transparent;color:${o};font-size:15px;font-weight:600;cursor:pointer;transition:all ${l}s ${c};" onmouseenter="this.style.background='${o}15';this.style.borderColor='${o}'" onmouseleave="this.style.background='transparent';this.style.borderColor='${o}44'">Learn More</button>
        <button style="padding:12px 28px;border:none;border-radius:${s}px;background:${o}15;color:${o};font-size:15px;font-weight:500;cursor:pointer;transition:all ${l}s ${c};" onmouseenter="this.style.background='${o}25'" onmouseleave="this.style.background='${o}15'">Tertiary</button>
      </div>`,modal:`
      <div style="position:relative;max-width:400px;width:100%;">
        <div style="position:fixed;inset:0;background:rgba(0,0,0,0.5);backdrop-filter:blur(8px);border-radius:${s}px;"></div>
        <div style="position:relative;${m} padding:32px; box-shadow:0 24px 48px rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.1); animation:pg-scale-in ${l}s ${c} both ${d}s;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <h3 style="font-size:18px;font-weight:600;color:${i};margin:0;">Confirm Action</h3>
            <span style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;color:${i}66;transition:background 0.2s;" onmouseenter="this.style.background='rgba(255,255,255,0.08)'" onmouseleave="this.style.background='transparent'">&times;</span>
          </div>
          <p style="font-size:14px;color:${i}88;margin:0 0 24px;line-height:1.6;">Are you sure you want to proceed? This action will apply the selected effects and update the component.</p>
          <div style="display:flex;gap:12px;justify-content:flex-end;">
            <button style="padding:10px 20px;border:1px solid rgba(255,255,255,0.1);border-radius:8px;background:transparent;color:${i}99;font-size:14px;cursor:pointer;">Cancel</button>
            <button style="padding:10px 20px;border:none;border-radius:8px;background:${o};color:white;font-size:14px;font-weight:600;cursor:pointer;">Confirm</button>
          </div>
        </div>
      </div>`,dashboard:`
      <div style="${m} padding:24px; max-width:400px; box-shadow:0 4px 24px rgba(0,0,0,${Y.shadow}); border:1px solid rgba(255,255,255,0.08);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
          <h3 style="font-size:16px;font-weight:600;color:${i};margin:0;">Dashboard</h3>
          <span style="font-size:12px;padding:4px 10px;border-radius:20px;background:#22c55e22;color:#22c55e;">Live</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;">
          ${[{label:"Users",val:"12.4K",change:"+12%"},{label:"Revenue",val:"$48.2K",change:"+8%"},{label:"Sessions",val:"89.1K",change:"+23%"},{label:"Bounce",val:"24.3%",change:"-5%"}].map(e=>`
            <div style="padding:14px;border-radius:${Math.max(8,s-4)}px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.05);">
              <div style="font-size:12px;color:${i}66;margin-bottom:6px;">${e.label}</div>
              <div style="font-size:20px;font-weight:700;color:${i};">${e.val}</div>
              <div style="font-size:11px;color:${e.change.startsWith("+")?"#22c55e":"#ef4444"};margin-top:4px;">${e.change}</div>
            </div>`).join("")}
        </div>
        <div style="height:80px;border-radius:8px;background:linear-gradient(180deg,${o}22 0%,transparent 100%);position:relative;overflow:hidden;">
          <svg width="100%" height="100%" viewBox="0 0 352 80" preserveAspectRatio="none">
            <polyline points="0,60 44,45 88,55 132,30 176,40 220,20 264,35 308,15 352,25" fill="none" stroke="${o}" stroke-width="2" stroke-linecap="round"/>
            <polyline points="0,60 44,45 88,55 132,30 176,40 220,20 264,35 308,15 352,25" fill="url(#pg-grad)" stroke="none"/>
            <defs><linearGradient id="pg-grad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${o}" stop-opacity="0.3"/><stop offset="100%" stop-color="${o}" stop-opacity="0"/></linearGradient></defs>
          </svg>
        </div>
      </div>`,navigation:`
      <div style="${m} padding:0 24px; height:56px; display:flex; align-items:center; justify-content:space-between; box-shadow:0 1px 3px rgba(0,0,0,${Y.shadow}); border:1px solid rgba(255,255,255,0.08); max-width:600px; width:100%;">
        <div style="display:flex;align-items:center;gap:8px;">
          <div style="width:28px;height:28px;border-radius:6px;background:linear-gradient(135deg,${o},${n});"></div>
          <span style="font-weight:700;font-size:15px;color:${i};">Ferrum</span>
        </div>
        <div style="display:flex;gap:24px;align-items:center;">
          ${["Products","Solutions","Docs","Pricing"].map(e=>`<span style="font-size:14px;color:${i}88;cursor:pointer;transition:color 0.2s;" onmouseenter="this.style.color='${i}'" onmouseleave="this.style.color='${i}88'">${e}</span>`).join("")}
        </div>
        <button style="padding:8px 18px;border:none;border-radius:8px;background:${o};color:white;font-size:13px;font-weight:600;cursor:pointer;">Get Started</button>
      </div>`,hero:`
      <div style="${m} padding:48px 32px; max-width:480px; text-align:center; border:1px solid rgba(255,255,255,0.08);">
        <span style="display:inline-block;padding:6px 16px;border-radius:20px;background:${o}18;color:${o};font-size:13px;font-weight:500;margin-bottom:20px;">v2.0 Now Available</span>
        <h1 style="font-size:36px;font-weight:800;line-height:1.1;margin:0 0 16px;background:linear-gradient(135deg,${i},${o});-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Build Stunning Interfaces</h1>
        <p style="font-size:15px;color:${i}77;margin:0 0 28px;line-height:1.7;max-width:380px;margin-left:auto;margin-right:auto;">The universal UI platform for creating beautiful, performant, and accessible web experiences.</p>
        <div style="display:flex;gap:12px;justify-content:center;">
          <button style="padding:12px 28px;border:none;border-radius:${s}px;background:linear-gradient(135deg,${o},${n});color:white;font-size:15px;font-weight:600;cursor:pointer;">Start Building</button>
          <button style="padding:12px 28px;border:1px solid ${i}22;border-radius:${s}px;background:transparent;color:${i}99;font-size:15px;cursor:pointer;">View Docs</button>
        </div>
      </div>`,"animated-card":`
      <div id="pg-tilt-card" style="${m} padding:28px; max-width:320px; box-shadow:0 4px 24px rgba(0,0,0,${Y.shadow}); border:1px solid rgba(255,255,255,0.08); transform-style:preserve-3d; transition:transform 0.15s ease-out,box-shadow 0.3s;" onmousemove="pg_handleTilt(event,this)" onmouseleave="pg_resetTilt(this)">
        <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,${o},${n});margin-bottom:18px;transition:transform 0.3s;"></div>
        <h3 style="font-size:18px;font-weight:600;margin:0 0 8px;color:${i}">3D Tilt Card</h3>
        <p style="font-size:14px;color:${i}88;margin:0;line-height:1.6;">Hover to see the 3D tilt effect with dynamic spotlight following your cursor.</p>
      </div>`,magnetic:`
      <div style="display:flex;gap:16px;align-items:center;justify-content:center;min-height:200px;">
        ${["Explore","Create","Ship"].map(e=>`
          <div class="pg-magnetic" style="padding:14px 28px;border-radius:${s}px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:${i};font-size:15px;font-weight:500;cursor:pointer;transition:transform 0.3s ${c},background 0.2s;" onmousemove="pg_magneticMove(event,this)" onmouseleave="pg_magneticReset(this)" onmouseenter="this.style.background='rgba(255,255,255,0.08)'">${e}</div>
        `).join("")}
      </div>`,"shine-button":`
      <div style="display:flex;gap:16px;align-items:center;justify-content:center;min-height:200px;">
        <button style="position:relative;overflow:hidden;padding:14px 32px;border:none;border-radius:${s}px;background:linear-gradient(135deg,${o},${n});color:white;font-size:16px;font-weight:600;cursor:pointer;">
          <span style="position:relative;z-index:1;">Shine Button</span>
          <span style="position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,0.25),transparent);transition:left 0.7s ${c};" onmouseenter="this.style.left='100%'" onmouseleave="this.style.left='-100%'"></span>
        </button>
      </div>`,"ripple-button":`
      <div style="display:flex;gap:16px;align-items:center;justify-content:center;min-height:200px;">
        <button onclick="pg_createRipple(event,this)" style="position:relative;overflow:hidden;padding:14px 32px;border:none;border-radius:${s}px;background:${o};color:white;font-size:16px;font-weight:600;cursor:pointer;">Click for Ripple</button>
      </div>`,"gradient-text":`
      <div style="text-align:center;padding:40px 20px;">
        <h1 style="font-size:48px;font-weight:800;margin:0;background:linear-gradient(135deg,${o},${n},${o});background-size:200% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:pg-gradient-shift ${4*l}s ${c} ${p};">Ferrum Engine</h1>
        <p style="font-size:18px;color:${i}77;margin:12px 0 0;">Beautiful gradient text with smooth animation</p>
      </div>`,"floating-element":`
      <div style="display:flex;gap:24px;align-items:end;justify-content:center;min-height:200px;">
        <div style="width:60px;height:60px;border-radius:${s}px;background:linear-gradient(135deg,${o}88,${n}88);animation:pg-float ${6*l}s ${c} ${d}s ${p};"></div>
        <div style="width:80px;height:80px;border-radius:${s}px;background:linear-gradient(135deg,${o},${n});animation:pg-float ${8*l}s ${c} ${d+.5}s ${p};"></div>
        <div style="width:60px;height:60px;border-radius:${s}px;background:linear-gradient(135deg,${n}88,${o}88);animation:pg-float ${5*l}s ${c} ${d+1}s ${p};"></div>
      </div>`,"border-glow-card":`
      <div style="position:relative;max-width:320px;border-radius:${s+2}px;padding:2px;background:linear-gradient(135deg,${o}66,${n}66,${o}66);background-size:200% 200%;animation:pg-border-rotate 4s linear ${p};">
        <div style="${m} padding:24px; border-radius:${s}px;">
          <h3 style="font-size:18px;font-weight:600;margin:0 0 8px;color:${i}">Border Glow Card</h3>
          <p style="font-size:14px;color:${i}88;margin:0;line-height:1.6;">Animated gradient border that rotates around the card continuously.</p>
        </div>
      </div>`,particles:`
      <div id="pg-particles" style="position:relative;width:100%;height:300px;overflow:hidden;border-radius:${s}px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);"></div>`,"border-beam":`
      <div style="position:relative;max-width:320px;padding:2px;border-radius:${s+2}px;overflow:hidden;">
        <div style="position:absolute;inset:0;border-radius:inherit;background:conic-gradient(from 0deg,transparent,${o},transparent,${n},transparent);animation:pg-spin 3s linear ${p};"></div>
        <div style="position:relative;${m} padding:24px; border-radius:${s}px;">
          <h3 style="font-size:18px;font-weight:600;margin:0 0 8px;color:${i}">Border Beam</h3>
          <p style="font-size:14px;color:${i}88;margin:0;line-height:1.6;">A rotating conic gradient creates this stunning border beam effect.</p>
        </div>
      </div>`,"gradient-orb":`
      <div style="display:flex;align-items:center;justify-content:center;min-height:250px;">
        <div style="width:120px;height:120px;border-radius:50%;background:radial-gradient(circle at 30% 30%,${o}cc,${n}88 50%,transparent 70%);filter:blur(0px);animation:pg-float ${6*l}s ${c} ${p};box-shadow:0 0 60px ${o}44,0 0 120px ${n}22;"></div>
      </div>`,"text-reveal":`
      <div style="text-align:center;padding:40px 20px;">
        <p style="font-size:28px;font-weight:600;color:${i};font-family:monospace;overflow:hidden;border-right:2px solid ${o};white-space:nowrap;animation:pg-typing 3s steps(20) ${d}s ${p},pg-blink 0.75s step-end infinite;">Building the future of UI</p>
      </div>`,"number-ticker":`
      <div style="display:flex;gap:24px;justify-content:center;padding:40px 20px;">
        ${[{label:"Downloads",val:"2.4M",color:o},{label:"Stars",val:"12.8K",color:n},{label:"Components",val:"542+",color:o}].map(e=>`
          <div style="text-align:center;">
            <div style="font-size:36px;font-weight:800;color:${e.color};">${e.val}</div>
            <div style="font-size:13px;color:${i}66;margin-top:4px;">${e.label}</div>
          </div>
        `).join("")}
      </div>`,shimmer:`
      <div style="max-width:320px;">
        <div style="height:16px;border-radius:4px;background:linear-gradient(90deg,rgba(255,255,255,0.04) 25%,rgba(255,255,255,0.1) 50%,rgba(255,255,255,0.04) 75%);background-size:200% 100%;animation:pg-shimmer 1.5s ease ${p};margin-bottom:12px;width:75%;"></div>
        <div style="height:16px;border-radius:4px;background:linear-gradient(90deg,rgba(255,255,255,0.04) 25%,rgba(255,255,255,0.1) 50%,rgba(255,255,255,0.04) 75%);background-size:200% 100%;animation:pg-shimmer 1.5s ease ${p};animation-delay:0.15s;margin-bottom:12px;width:100%;"></div>
        <div style="height:16px;border-radius:4px;background:linear-gradient(90deg,rgba(255,255,255,0.04) 25%,rgba(255,255,255,0.1) 50%,rgba(255,255,255,0.04) 75%);background-size:200% 100%;animation:pg-shimmer 1.5s ease ${p};animation-delay:0.3s;width:50%;"></div>
      </div>`,"pulsing-dot":`
      <div style="display:flex;gap:24px;align-items:center;justify-content:center;min-height:200px;">
        ${[{c:"#22c55e",l:"Online"},{c:"#eab308",l:"Away"},{c:"#ef4444",l:"Busy"}].map(e=>`
          <div style="display:flex;align-items:center;gap:8px;">
            <span style="position:relative;width:10px;height:10px;display:block;">
              <span style="position:absolute;inset:0;border-radius:50%;background:${e.c};animation:pg-ping 1.5s ${c} ${p};opacity:0.75;"></span>
              <span style="position:relative;display:block;width:10px;height:10px;border-radius:50%;background:${e.c};"></span>
            </span>
            <span style="font-size:14px;color:${i}88;">${e.l}</span>
          </div>
        `).join("")}
      </div>`})[E]??g.card,r=F||void 0,`<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
*{margin:0;padding:0;box-sizing:border-box;}
body{background:${Y.bg};display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px;font-family:system-ui,-apple-system,sans-serif;}

/* Playground keyframes */
@keyframes pg-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
@keyframes pg-gradient-shift{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
@keyframes pg-border-rotate{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes pg-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@keyframes pg-shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
@keyframes pg-ping{75%,100%{transform:scale(2.5);opacity:0}}
@keyframes pg-pulse{0%,100%{opacity:1}50%{opacity:0.7}}
@keyframes pg-scale-in{from{opacity:0;transform:scale(0.95) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}
@keyframes pg-blink{from,to{border-color:transparent}50%{border-color:${Y.primary}}}
@keyframes pg-typing{from{width:0}to{width:100%}}

${el||""}

${r?`.${r} { animation-duration: ${P.duration}s !important; animation-delay: ${P.delay}s !important; animation-timing-function: ${P.easing} !important; animation-iteration-count: ${"infinite"===P.iterations?"infinite":P.iterations} !important; animation-direction: ${P.direction} !important; animation-fill-mode: ${P.fillMode} !important; }`:""}
</style></head><body>
${r?`<div class="${r}">`:""}${t}${r?"</div>":""}
<script>
function pg_handleTilt(e,el){var r=el.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top,cx=r.width/2,cy=r.height/2,rx=((y-cy)/cy)*-8,ry=((x-cx)/cx)*8;el.style.transform='perspective(800px) rotateX('+rx+'deg) rotateY('+ry+'deg)';el.style.boxShadow='0 20px 40px rgba(0,0,0,0.3)';var s=document.createElement('div');s.style.cssText='position:absolute;inset:0;pointer-events:none;border-radius:inherit;opacity:0.4;background:radial-gradient(400px circle at '+(x/r.width*100)+'% '+(y/r.height*100)+'%,${Y.primary}33,transparent 40%)';el.querySelectorAll('.pg-spot').forEach(function(p){p.remove()});s.className='pg-spot';el.appendChild(s);}
function pg_resetTilt(el){el.style.transform='';el.style.boxShadow='0 4px 24px rgba(0,0,0,${Y.shadow})';el.querySelectorAll('.pg-spot').forEach(function(p){p.remove()});}
function pg_magneticMove(e,el){var r=el.getBoundingClientRect(),x=e.clientX-r.left-r.width/2,y=e.clientY-r.top-r.height/2;el.style.transform='translate('+x*0.3+'px,'+y*0.3+'px)';}
function pg_magneticReset(el){el.style.transform='translate(0,0)';}
function pg_createRipple(e,btn){var r=btn.getBoundingClientRect(),s=document.createElement('span'),sz=Math.max(r.width,r.height);s.style.cssText='position:absolute;border-radius:50%;background:rgba(255,255,255,0.3);width:'+sz+'px;height:'+sz+'px;left:'+(e.clientX-r.left-sz/2)+'px;top:'+(e.clientY-r.top-sz/2)+'px;transform:scale(0);animation:pg-ripple 0.6s ease-out forwards;pointer-events:none;';btn.appendChild(s);setTimeout(function(){s.remove()},600);}
@keyframes pg-ripple{to{transform:scale(4);opacity:0}}
</script>
${t.includes("pg-particles")?`
<script>
(function(){var c=document.getElementById('pg-particles');if(!c)return;for(var i=0;i<30;i++){var p=document.createElement('div');var s=1+Math.random()*3;p.style.cssText='position:absolute;width:'+s+'px;height:'+s+'px;border-radius:50%;background:${Y.primary};opacity:'+(0.15+Math.random()*0.3)+';left:'+Math.random()*100+'%;top:'+Math.random()*100+'%;animation:pg-float '+(6+Math.random()*10)+'s ease-in-out '+Math.random()*5+'s infinite;';c.appendChild(p);}})();
</script>`:""}
</body></html>`},[E,Y,P,el,F,S]),ep=(0,n.useMemo)(()=>(function(e,t,r,o){let n=t.primary,a=t.radius,i=r.easing,s=r.duration,l=`  transition: all ${s}s ${i};`;switch(e){case"html":return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ferrum Component</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: system-ui, -apple-system, sans-serif;
      background: ${t.bg};
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 24px;
    }
    .ferrum-component {
      background: ${t.surface};
      color: ${t.text};
      border-radius: ${a}px;
      padding: 24px;
      box-shadow: 0 4px 24px rgba(0, 0, 0, ${t.shadow});
      border: 1px solid rgba(255, 255, 255, 0.08);
      ${l}
    }
    .ferrum-component:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 32px ${n}33;
    }
    ${o?`.${o} { animation-duration: ${s}s; animation-timing-function: ${i}; animation-iteration-count: ${r.iterations}; }`:""}
  </style>
  <link rel="stylesheet" href="https://unpkg.com/ferrumcss@latest/dist/ferrum.css">
</head>
<body>
  <div class="ferrum-component${o?` ${o}`:""}">
    <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">
      Ferrum Component
    </h3>
    <p style="font-size: 14px; opacity: 0.7; line-height: 1.6;">
      Built with FerrumEngine — zero dependencies, pure CSS.
    </p>
  </div>
</body>
</html>`;case"css":return`/* ═══════════════════════════════════════
   Ferrum Component — Generated by Playground 2.0
   ═══════════════════════════════════════ */

.ferrum-component {
  background: ${t.surface};
  color: ${t.text};
  border-radius: ${a}px;
  padding: 24px;
  box-shadow: 0 4px 24px rgba(0, 0, 0, ${t.shadow});
  border: 1px solid rgba(255, 255, 255, 0.08);
  ${l}
}

.ferrum-component:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 32px ${n}33;
}

${o?`.${o} {
  animation-duration: ${s}s;
  animation-timing-function: ${i};
  animation-iteration-count: ${r.iterations};
}`:""}

/* Usage: <div class="ferrum-component${o?` ${o}`:""}">...</div> */`;case"react":return`import React, { useState } from "react";

interface FerrumComponentProps {
  children?: React.ReactNode;
  className?: string;
  effect?: string;
}

export function FerrumComponent({
  children,
  className = "",
  effect,
}: FerrumComponentProps) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className={\`ferrum-component \${effect || ""} \${className}\`}
      style={{
        background: "${t.surface}",
        color: "${t.text}",
        borderRadius: "${a}px",
        padding: "24px",
        boxShadow: hovered
          ? "0 8px 32px ${n}33"
          : "0 4px 24px rgba(0, 0, 0, ${t.shadow})",
        border: "1px solid rgba(255, 255, 255, 0.08)",
        transform: hovered ? "translateY(-4px)" : "none",
        transition: \`all \${${s}}s ${i}\`,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {children || (
        <>
          <h3 style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>
            Ferrum Component
          </h3>
          <p style={{ fontSize: 14, opacity: 0.7, lineHeight: 1.6 }}>
            Built with FerrumEngine.
          </p>
        </>
      )}
    </div>
  );
}

// Usage: <FerrumComponent${o?` effect="${o}"`:""} />`;case"vue":return`<template>
  <div
    class="ferrum-component"
    :class="effect"
    :style="componentStyle"
    @mouseenter="hovered = true"
    @mouseleave="hovered = false"
  >
    <slot>
      <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">
        Ferrum Component
      </h3>
      <p style="font-size: 14px; opacity: 0.7; line-height: 1.6;">
        Built with FerrumEngine.
      </p>
    </slot>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from "vue";

const props = withDefaults(defineProps<{
  effect?: string;
}>(), {
  effect: "${o||""}",
});

const hovered = ref(false);

const componentStyle = computed(() => ({
  background: "${t.surface}",
  color: "${t.text}",
  borderRadius: "${a}px",
  padding: "24px",
  boxShadow: hovered.value
    ? "0 8px 32px ${n}33"
    : "0 4px 24px rgba(0, 0, 0, ${t.shadow})",
  border: "1px solid rgba(255, 255, 255, 0.08)",
  transform: hovered.value ? "translateY(-4px)" : "none",
  transition: \`all ${s}s ${i}\`,
}));
</script>`;case"svelte":return`<script lang="ts">
  let hovered = $state(false);
  export let effect: string = "${o||""}";
</script>

<div
  class="ferrum-component {effect}"
  style="
    background: {theme.surface};
    color: {theme.text};
    border-radius: {r}px;
    padding: 24px;
    box-shadow: {hovered ? '0 8px 32px ${n}33' : '0 4px 24px rgba(0, 0, 0, ${t.shadow})'};
    border: 1px solid rgba(255, 255, 255, 0.08);
    transform: {hovered ? 'translateY(-4px)' : 'none'};
    transition: all ${s}s ${i};
  "
  onmouseenter={() => (hovered = true)}
  onmouseleave={() => (hovered = false)}
>
  <slot>
    <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">
      Ferrum Component
    </h3>
    <p style="font-size: 14px; opacity: 0.7; line-height: 1.6;">
      Built with FerrumEngine.
    </p>
  </slot>
</div>`;case"angular":return`import { Component, Input } from "@angular/core";

@Component({
  selector: "ferrum-component",
  template: \`
    <div
      class="ferrum-component"
      [ngClass]="effect"
      [ngStyle]="componentStyle"
      (mouseenter)="hovered = true"
      (mouseleave)="hovered = false"
    >
      <ng-content>
        <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">
          Ferrum Component
        </h3>
        <p style="font-size: 14px; opacity: 0.7; line-height: 1.6;">
          Built with FerrumEngine.
        </p>
      </ng-content>
    </div>
  \`,
  styles: [\`
    .ferrum-component {
      display: block;
    }
  \`],
})
export class FerrumComponent {
  @Input() effect = "${o||""}";
  hovered = false;

  get componentStyle() {
    return {
      background: "${t.surface}",
      color: "${t.text}",
      borderRadius: "${a}px",
      padding: "24px",
      boxShadow: this.hovered
        ? "0 8px 32px ${n}33"
        : "0 4px 24px rgba(0, 0, 0, ${t.shadow})",
      border: "1px solid rgba(255, 255, 255, 0.08)",
      transform: this.hovered ? "translateY(-4px)" : "none",
      transition: \`all ${s}s ${i}\`,
    };
  }
}

// Usage: <ferrum-component${o?` effect="${o}"`:""}></ferrum-component>`;case"webcomponents":return`class FerrumComponent extends HTMLElement {
  static get observedAttributes() {
    return ["effect"];
  }

  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._hovered = false;
    this._onMouseEnter = this._handleMouseEnter.bind(this);
    this._onMouseLeave = this._handleMouseLeave.bind(this);
  }

  connectedCallback() {
    this.render();
    const host = this.shadowRoot.querySelector(".host");
    if (host) {
      host.addEventListener("mouseenter", this._onMouseEnter);
      host.addEventListener("mouseleave", this._onMouseLeave);
    }
  }

  disconnectedCallback() {
    if (this.shadowRoot) {
      const host = this.shadowRoot.querySelector(".host");
      if (host) {
        host.removeEventListener("mouseenter", this._onMouseEnter);
        host.removeEventListener("mouseleave", this._onMouseLeave);
      }
    }
  }

  _handleMouseEnter() {
    this._hovered = true;
    this._updateStyles();
  }

  _handleMouseLeave() {
    this._hovered = false;
    this._updateStyles();
  }

  _updateStyles() {
    const host = this.shadowRoot.querySelector(".host");
    if (!host) return;
    host.style.boxShadow = this._hovered
      ? "0 8px 32px ${n}33"
      : "0 4px 24px rgba(0, 0, 0, ${t.shadow})";
    host.style.transform = this._hovered ? "translateY(-4px)" : "none";
  }

  get effect() {
    return this.getAttribute("effect") || "${o||""}";
  }

  render() {
    this.shadowRoot.innerHTML = \`
      <style>
        .host {
          background: ${t.surface};
          color: ${t.text};
          border-radius: ${a}px;
          padding: 24px;
          box-shadow: \${this._hovered
            ? "0 8px 32px ${n}33"
            : "0 4px 24px rgba(0, 0, 0, ${t.shadow})"};
          border: 1px solid rgba(255, 255, 255, 0.08);
          transform: \${this._hovered ? "translateY(-4px)" : "none"};
          transition: all ${s}s ${i};
          display: block;
          cursor: pointer;
        }
        h3 { font-size: 18px; font-weight: 600; margin-bottom: 8px; }
        p { font-size: 14px; opacity: 0.7; line-height: 1.6; }
      </style>
      <div class="host">
        <slot>
          <h3>Ferrum Component</h3>
          <p>Built with FerrumEngine.</p>
        </slot>
      </div>
    \`;
  }
}

customElements.define("ferrum-component", FerrumComponent);

// Usage: <ferrum-component${o?` effect="${o}"`:""}></ferrum-component>`;default:return""}})(h,Y,P,F||void 0),[h,E,Y,P,F]),eu=null!==j?j:ep,ex=(0,n.useCallback)(e=>{$(e)},[]);(0,n.useEffect)(()=>{$(null)},[h,E,F]),(0,n.useEffect)(()=>()=>{y.current&&clearTimeout(y.current)},[]);let em=(0,n.useMemo)(()=>{let e=new DOMParser().parseFromString(ec,"text/html").querySelectorAll("*").length,t=(ec.match(/\{[^}]*\}/g)||[]).length,r=(ec.match(/animation:/g)||[]).length,o=Math.max(1,Math.round(.05*e+.02*t));return{domNodes:e,cssRules:t,animations:r,renderTime:o}},[ec]),eg=(0,n.useCallback)(e=>{I(t=>({...t,...e}))},[]),eh=(0,n.useCallback)(e=>{V(t=>({...t,...e}))},[]),ef=(0,n.useCallback)(e=>{q(t=>({...t,...e}))},[]),eb=(0,n.useCallback)(async()=>{try{await navigator.clipboard.writeText(ep),v(!0),y.current&&clearTimeout(y.current),y.current=setTimeout(()=>v(!1),2e3)}catch(e){console.warn("[Ferrum] Clipboard write failed",e),a.toast.error("Failed to copy to clipboard")}},[ep]),ev=(0,n.useCallback)(()=>{let e=new Blob([ep],{type:"text/plain"}),t=URL.createObjectURL(e),r=document.createElement("a");r.href=t,r.download=`ferrum-${E}.${"html"===h?"html":"css"===h?"css":"react"===h?"tsx":"vue"===h?"vue":"svelte"===h?"svelte":"angular"===h?"ts":"js"}`,r.click(),URL.revokeObjectURL(t)},[ep,E,h]),ey=(0,n.useCallback)(e=>{A(e.components[0]??"card"),R("")},[]);return(0,n.useEffect)(()=>{let e=e=>{(e.metaKey||e.ctrlKey)&&"1"===e.key&&(e.preventDefault(),g("split")),(e.metaKey||e.ctrlKey)&&"2"===e.key&&(e.preventDefault(),g("code")),(e.metaKey||e.ctrlKey)&&"3"===e.key&&(e.preventDefault(),g("preview")),(e.metaKey||e.ctrlKey)&&"b"===e.key&&(e.preventDefault(),W(e=>!e)),(e.metaKey||e.ctrlKey)&&"e"===e.key&&(e.preventDefault(),Z(e=>!e)),"Escape"===e.key&&i(),(e.metaKey||e.ctrlKey)&&"c"===e.key&&!window.getSelection()?.toString()&&(e.preventDefault(),eb()),(e.metaKey||e.ctrlKey)&&"s"===e.key&&(e.preventDefault(),ev())};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[i,eb,ev]),(0,t.jsx)(s,{children:(0,t.jsxs)("div",{className:"fixed inset-0 bg-background flex flex-col z-50",style:{paddingTop:0},children:[(0,t.jsx)(et,{onBack:i,viewMode:m,onViewModeChange:g,onExport:ev,copied:b,onCopy:eb}),(0,t.jsxs)("div",{className:"flex-1 flex min-h-0",children:[G&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(O,{active:u,onChange:x}),(0,t.jsx)("div",{style:{width:ee},className:"min-w-0 shrink-0",children:(0,t.jsx)(H,{activity:u,selectedComponent:E,onSelectComponent:e=>{A(e),R("")},selectedEffect:F,onSelectEffect:R,onSelectTemplate:ey,effectsList:ei,search:k,setSearch:N,effectCategory:C,setEffectCategory:z})}),(0,t.jsx)(er,{direction:"horizontal",onResize:e=>eo(t=>Math.min(400,Math.max(180,t+e)))})]}),(0,t.jsxs)("div",{className:"flex-1 flex flex-col min-w-0",children:["split"===m&&(0,t.jsxs)("div",{className:"flex-1 flex flex-col min-h-0",children:[(0,t.jsx)("div",{style:{height:`${J}%`},className:"min-h-0",children:(0,t.jsx)(w,{code:eu,format:h,onFormatChange:f,onCodeChange:ex,onCopy:eb,copied:b})}),(0,t.jsx)(er,{direction:"vertical",onResize:e=>Q(t=>Math.min(85,Math.max(15,t+.3*e)))}),(0,t.jsx)("div",{style:{height:`${100-J}%`},className:"min-h-0",children:(0,t.jsx)(U,{html:ec,device:B,customWidth:D,onDeviceChange:T})})]}),"code"===m&&(0,t.jsx)("div",{className:"flex-1 min-h-0",children:(0,t.jsx)(w,{code:eu,format:h,onFormatChange:f,onCodeChange:ex,onCopy:eb,copied:b})}),"preview"===m&&(0,t.jsx)("div",{className:"flex-1 min-h-0",children:(0,t.jsx)(U,{html:ec,device:B,customWidth:D,onDeviceChange:T})})]}),X&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(er,{direction:"horizontal",onResize:e=>ea(t=>Math.min(440,Math.max(220,t+e)))}),(0,t.jsx)("div",{style:{width:en},className:"min-w-0 shrink-0 overflow-hidden",children:(0,t.jsx)(_,{motion:P,onMotionChange:eg,physics:K,onPhysicsChange:eh,theme:Y,onThemeChange:ef,selectedComponent:E,selectedEffect:F,metrics:em,reducedMotion:S,onToggleReducedMotion:()=>M(e=>!e)})})]})]}),(0,t.jsxs)("div",{className:"h-7 bg-foreground/[0.02] border-t border-border flex items-center px-3 text-[10px] text-muted-foreground/40 shrink-0 gap-4",children:[(0,t.jsxs)("div",{className:"flex items-center gap-1.5",children:[(0,t.jsx)("div",{className:"w-1.5 h-1.5 rounded-full bg-green-500/60"}),(0,t.jsx)("span",{children:"Ready"})]}),(0,t.jsxs)("div",{className:"flex items-center gap-1",children:[(0,t.jsx)(o.Cpu,{size:10}),(0,t.jsxs)("span",{children:[em.domNodes," nodes"]})]}),(0,t.jsxs)("div",{className:"flex items-center gap-1",children:[(0,t.jsx)(r.Activity,{size:10}),(0,t.jsxs)("span",{children:[em.animations," animations"]})]}),(0,t.jsx)("div",{className:"flex-1"}),(0,t.jsx)("div",{children:"FerrumEngine Playground 2.0"}),(0,t.jsxs)("div",{children:[ei.length,"+ effects"]})]})]})})}],35458)},43700,function(e){e.n(e.i(35458))}]);