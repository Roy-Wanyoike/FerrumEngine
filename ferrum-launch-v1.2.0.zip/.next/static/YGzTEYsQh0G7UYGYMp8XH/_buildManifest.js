self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/principles",
        "destination": "/"
      },
      {
        "source": "/architecture",
        "destination": "/"
      },
      {
        "source": "/platform-architecture",
        "destination": "/"
      },
      {
        "source": "/hall-of-fame",
        "destination": "/"
      },
      {
        "source": "/showcase",
        "destination": "/"
      },
      {
        "source": "/learning",
        "destination": "/"
      },
      {
        "source": "/story",
        "destination": "/"
      },
      {
        "source": "/enterprise",
        "destination": "/"
      },
      {
        "source": "/enterprise-components",
        "destination": "/"
      },
      {
        "source": "/vision",
        "destination": "/"
      },
      {
        "source": "/effects",
        "destination": "/"
      },
      {
        "source": "/docs",
        "destination": "/"
      },
      {
        "source": "/playground",
        "destination": "/"
      },
      {
        "source": "/community",
        "destination": "/"
      },
      {
        "source": "/blog",
        "destination": "/"
      },
      {
        "source": "/changelog",
        "destination": "/"
      },
      {
        "source": "/interactive-docs",
        "destination": "/"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()