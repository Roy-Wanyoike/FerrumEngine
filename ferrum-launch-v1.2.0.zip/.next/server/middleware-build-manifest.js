globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/YGzTEYsQh0G7UYGYMp8XH/_buildManifest.js",
    "static/YGzTEYsQh0G7UYGYMp8XH/_ssgManifest.js",
    "static/YGzTEYsQh0G7UYGYMp8XH/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0oeds6xg-zier.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/2ts65czrjjd_k.js",
    "static/chunks/01l32msd8my4u.js",
    "static/chunks/turbopack-0tor58xkx9rnr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
