module.exports=[97764,a=>{"use strict";var b=a.i(87924);let c=(0,a.i(19721).default)(async()=>{},{loadableGenerated:{modules:[85537]},ssr:!1});a.s(["CloudLoader",0,function(){return(0,b.jsx)(c,{})}])}];

//# sourceMappingURL=src_app_cloud_cloud-loader_tsx_0uo9r8s._.js.map