module.exports=[12065,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cloud_page_actions_066bcl6.js.map