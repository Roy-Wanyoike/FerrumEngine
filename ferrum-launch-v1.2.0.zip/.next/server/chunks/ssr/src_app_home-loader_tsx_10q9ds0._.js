module.exports=[51879,a=>{"use strict";var b=a.i(87924);let c=(0,a.i(19721).default)(async()=>{},{loadableGenerated:{modules:[14536]},ssr:!1});a.s(["HomeLoader",0,function(){return(0,b.jsx)(c,{})}])}];

//# sourceMappingURL=src_app_home-loader_tsx_10q9ds0._.js.map