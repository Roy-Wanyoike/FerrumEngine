module.exports=[18743,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tokens_route_actions_1ztm_he.js.map