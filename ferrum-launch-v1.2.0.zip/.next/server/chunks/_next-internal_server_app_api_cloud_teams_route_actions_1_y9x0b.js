module.exports=[73417,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cloud_teams_route_actions_1_y9x0b.js.map