module.exports=[11123,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cloud_teams_%5BteamId%5D_route_actions_1wvjaqh.js.map