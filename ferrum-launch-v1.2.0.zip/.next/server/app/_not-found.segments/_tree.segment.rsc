:HL["/_next/static/chunks/03c6yop4mqd3w.css","style"]
:HL["/_next/static/chunks/16vlcg7b7kwst.css","style"]
:HL["/ferrum-effects.css","style",{"media":"print"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4116,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"YGzTEYsQh0G7UYGYMp8XH"}
