var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tokens/route.js")
R.c("server/chunks/[externals]__1alj1tf._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0rv_tu_._.js")
R.c("server/chunks/_next-internal_server_app_api_tokens_route_actions_1ztm_he.js")
R.m(81848)
module.exports=R.m(81848).exports
