var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/projects/[projectId]/tokens/route.js")
R.c("server/chunks/[root-of-the-server]__1l_tzg9._.js")
R.c("server/chunks/[root-of-the-server]__09qsmm9._.js")
R.c("server/chunks/src_lib_supabase-store_ts_0bvdqg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_cloud_projects_[projectId]_tokens_route_actions_0ybpkou.js")
R.m(11681)
module.exports=R.m(11681).exports
