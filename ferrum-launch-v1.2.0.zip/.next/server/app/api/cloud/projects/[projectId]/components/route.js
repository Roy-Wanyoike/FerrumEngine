var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/projects/[projectId]/components/route.js")
R.c("server/chunks/[root-of-the-server]__13wf7fd._.js")
R.c("server/chunks/[root-of-the-server]__09qsmm9._.js")
R.c("server/chunks/src_lib_supabase-store_ts_0bvdqg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_cloud_projects_[projectId]_components_route_actions_0qwofn6.js")
R.m(31830)
module.exports=R.m(31830).exports
