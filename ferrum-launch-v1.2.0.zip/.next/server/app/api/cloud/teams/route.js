var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/teams/route.js")
R.c("server/chunks/[root-of-the-server]__1qgwpmx._.js")
R.c("server/chunks/[root-of-the-server]__09qsmm9._.js")
R.c("server/chunks/src_lib_supabase-store_ts_0bvdqg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cloud_teams_route_actions_1_y9x0b.js")
R.m(1906)
module.exports=R.m(1906).exports
