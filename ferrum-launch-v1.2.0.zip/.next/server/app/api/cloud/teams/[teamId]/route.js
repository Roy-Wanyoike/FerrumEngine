var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/teams/[teamId]/route.js")
R.c("server/chunks/[root-of-the-server]__1gvxf1y._.js")
R.c("server/chunks/[root-of-the-server]__09qsmm9._.js")
R.c("server/chunks/src_lib_supabase-store_ts_0bvdqg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cloud_teams_[teamId]_route_actions_1wvjaqh.js")
R.m(43337)
module.exports=R.m(43337).exports
