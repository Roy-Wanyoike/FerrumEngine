var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/teams/[teamId]/projects/route.js")
R.c("server/chunks/[root-of-the-server]__12w0ay1._.js")
R.c("server/chunks/[root-of-the-server]__09qsmm9._.js")
R.c("server/chunks/src_lib_supabase-store_ts_0bvdqg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_cloud_teams_[teamId]_projects_route_actions_0eg544c.js")
R.m(33782)
module.exports=R.m(33782).exports
