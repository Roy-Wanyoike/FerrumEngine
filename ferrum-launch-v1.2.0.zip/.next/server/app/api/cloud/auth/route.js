var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/auth/route.js")
R.c("server/chunks/[externals]__1alj1tf._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__06c5kal._.js")
R.c("server/chunks/_next-internal_server_app_api_cloud_auth_route_actions_0sab7o4.js")
R.m(83620)
module.exports=R.m(83620).exports
