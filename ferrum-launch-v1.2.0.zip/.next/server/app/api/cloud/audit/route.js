var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cloud/audit/route.js")
R.c("server/chunks/[root-of-the-server]__0vu8q3c._.js")
R.c("server/chunks/[root-of-the-server]__09qsmm9._.js")
R.c("server/chunks/src_lib_supabase-store_ts_0bvdqg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cloud_audit_route_actions_0bdov9o.js")
R.m(1234)
module.exports=R.m(1234).exports
