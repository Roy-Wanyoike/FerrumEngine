var R=require("../../chunks/[turbopack]_runtime.js")("server/app/api/route.js")
R.c("server/chunks/[root-of-the-server]__0bvcl19._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_ferrum-effects-index_ts_0h20z8t._.js")
R.c("server/chunks/_next-internal_server_app_api_route_actions_1spy6eg.js")
R.m(91070)
module.exports=R.m(91070).exports
