var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/css/route.js")
R.c("server/chunks/[externals]__1alj1tf._.js")
R.c("server/chunks/src_lib_ferrum-effects-index_ts_0h20z8t._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_11g52wj._.js")
R.c("server/chunks/_next-internal_server_app_api_css_route_actions_1k6tr4w.js")
R.m(70227)
module.exports=R.m(70227).exports
