:HL["/_next/static/chunks/03c6yop4mqd3w.css","style"]
:HL["/_next/static/chunks/16vlcg7b7kwst.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/ferrum-effects.css","style",{"media":"print"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4116,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4224,"slots":null}}},"staleTime":300,"buildId":"YGzTEYsQh0G7UYGYMp8XH"}
